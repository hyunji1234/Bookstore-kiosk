﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 키오스크
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((listBox1.SelectedItem == null) || (listBox2.SelectedItem == null))
            {
                MessageBox.Show("결제 수단과 방법을 다시 확인해주세요");
                return;
            }

            else if (listBox1.SelectedIndex == 0)
            {
                MessageBox.Show(listBox1.Text + "(으)로" + listBox2.Text + "를\n선택하셨습니다.");
                MessageBox.Show("카드를 꽂아주세요.");
            }

            else if (listBox1.SelectedIndex == 1)
            {
                MessageBox.Show(listBox1.Text + "(으)로" + listBox2.Text + "를\n선택하셨습니다.");
                MessageBox.Show("카드를 대주세요.");
            }

            else if (listBox1.SelectedIndex == 2)
            {
                MessageBox.Show(listBox1.Text + "(으)로" + listBox2.Text + "를\n선택하셨습니다.");
                MessageBox.Show("바코드리더에 바코드를 읽혀주세요.");
            }



            MessageBox.Show("결제가 완료되었습니다.");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            colorDialog.ShowDialog();
            this.BackColor = colorDialog.Color;
        }
    }
}
