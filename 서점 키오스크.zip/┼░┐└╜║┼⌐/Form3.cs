﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace 키오스크
{
    public partial class Form3 : Form
    {
        Form1 frm1;
        public Form3(Form1 frm1)
        {
            InitializeComponent();
            this.frm1 = frm1;
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            frm1.listView1.Items.Add(new ListViewItem(new string[] { frm1.checkBox6.Text, frm1.label6.Text, 1.ToString() }));
            int price = int.Parse(frm1.label6.Text);

            frm1.textBox2.Text = null;
            
            this.Close();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
