﻿namespace 키오스크
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new System.Windows.Forms.TabControl();
            tabPageBest = new System.Windows.Forms.TabPage();
            tabControl3 = new System.Windows.Forms.TabControl();
            tabPageDay = new System.Windows.Forms.TabPage();
            pictureBox9 = new System.Windows.Forms.PictureBox();
            pictureBox6 = new System.Windows.Forms.PictureBox();
            pictureBox3 = new System.Windows.Forms.PictureBox();
            pictureBox8 = new System.Windows.Forms.PictureBox();
            pictureBox7 = new System.Windows.Forms.PictureBox();
            pictureBox5 = new System.Windows.Forms.PictureBox();
            pictureBox4 = new System.Windows.Forms.PictureBox();
            pictureBox2 = new System.Windows.Forms.PictureBox();
            pictureBox1 = new System.Windows.Forms.PictureBox();
            label10 = new System.Windows.Forms.Label();
            textBox1 = new System.Windows.Forms.TextBox();
            label9 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            checkBox8 = new System.Windows.Forms.CheckBox();
            checkBox6 = new System.Windows.Forms.CheckBox();
            checkBox7 = new System.Windows.Forms.CheckBox();
            checkBox9 = new System.Windows.Forms.CheckBox();
            checkBox5 = new System.Windows.Forms.CheckBox();
            checkBox4 = new System.Windows.Forms.CheckBox();
            checkBox3 = new System.Windows.Forms.CheckBox();
            checkBox2 = new System.Windows.Forms.CheckBox();
            checkBox1 = new System.Windows.Forms.CheckBox();
            tabPageWeek = new System.Windows.Forms.TabPage();
            label80 = new System.Windows.Forms.Label();
            label12 = new System.Windows.Forms.Label();
            textBox5 = new System.Windows.Forms.TextBox();
            textBox3 = new System.Windows.Forms.TextBox();
            pictureBox18 = new System.Windows.Forms.PictureBox();
            pictureBox17 = new System.Windows.Forms.PictureBox();
            pictureBox16 = new System.Windows.Forms.PictureBox();
            pictureBox15 = new System.Windows.Forms.PictureBox();
            pictureBox13 = new System.Windows.Forms.PictureBox();
            pictureBox14 = new System.Windows.Forms.PictureBox();
            pictureBox11 = new System.Windows.Forms.PictureBox();
            pictureBox12 = new System.Windows.Forms.PictureBox();
            pictureBox10 = new System.Windows.Forms.PictureBox();
            label13 = new System.Windows.Forms.Label();
            label14 = new System.Windows.Forms.Label();
            label15 = new System.Windows.Forms.Label();
            label16 = new System.Windows.Forms.Label();
            label17 = new System.Windows.Forms.Label();
            label18 = new System.Windows.Forms.Label();
            label19 = new System.Windows.Forms.Label();
            label20 = new System.Windows.Forms.Label();
            label21 = new System.Windows.Forms.Label();
            checkBox10 = new System.Windows.Forms.CheckBox();
            checkBox11 = new System.Windows.Forms.CheckBox();
            checkBox12 = new System.Windows.Forms.CheckBox();
            checkBox13 = new System.Windows.Forms.CheckBox();
            checkBox14 = new System.Windows.Forms.CheckBox();
            checkBox15 = new System.Windows.Forms.CheckBox();
            checkBox16 = new System.Windows.Forms.CheckBox();
            checkBox17 = new System.Windows.Forms.CheckBox();
            checkBox18 = new System.Windows.Forms.CheckBox();
            tabPageMonth = new System.Windows.Forms.TabPage();
            pictureBox25 = new System.Windows.Forms.PictureBox();
            pictureBox24 = new System.Windows.Forms.PictureBox();
            pictureBox23 = new System.Windows.Forms.PictureBox();
            pictureBox22 = new System.Windows.Forms.PictureBox();
            pictureBox20 = new System.Windows.Forms.PictureBox();
            pictureBox27 = new System.Windows.Forms.PictureBox();
            pictureBox26 = new System.Windows.Forms.PictureBox();
            pictureBox21 = new System.Windows.Forms.PictureBox();
            pictureBox19 = new System.Windows.Forms.PictureBox();
            label22 = new System.Windows.Forms.Label();
            textBox4 = new System.Windows.Forms.TextBox();
            label23 = new System.Windows.Forms.Label();
            label24 = new System.Windows.Forms.Label();
            label25 = new System.Windows.Forms.Label();
            label26 = new System.Windows.Forms.Label();
            label27 = new System.Windows.Forms.Label();
            label28 = new System.Windows.Forms.Label();
            label29 = new System.Windows.Forms.Label();
            label30 = new System.Windows.Forms.Label();
            label31 = new System.Windows.Forms.Label();
            checkBox19 = new System.Windows.Forms.CheckBox();
            checkBox20 = new System.Windows.Forms.CheckBox();
            checkBox21 = new System.Windows.Forms.CheckBox();
            checkBox22 = new System.Windows.Forms.CheckBox();
            checkBox23 = new System.Windows.Forms.CheckBox();
            checkBox24 = new System.Windows.Forms.CheckBox();
            checkBox25 = new System.Windows.Forms.CheckBox();
            checkBox26 = new System.Windows.Forms.CheckBox();
            checkBox27 = new System.Windows.Forms.CheckBox();
            tabPageCate = new System.Windows.Forms.TabPage();
            tabControl2 = new System.Windows.Forms.TabControl();
            tabPageNovel = new System.Windows.Forms.TabPage();
            pictureBox28 = new System.Windows.Forms.PictureBox();
            pictureBox29 = new System.Windows.Forms.PictureBox();
            pictureBox30 = new System.Windows.Forms.PictureBox();
            pictureBox31 = new System.Windows.Forms.PictureBox();
            pictureBox32 = new System.Windows.Forms.PictureBox();
            pictureBox33 = new System.Windows.Forms.PictureBox();
            pictureBox34 = new System.Windows.Forms.PictureBox();
            pictureBox35 = new System.Windows.Forms.PictureBox();
            pictureBox36 = new System.Windows.Forms.PictureBox();
            label33 = new System.Windows.Forms.Label();
            label34 = new System.Windows.Forms.Label();
            label35 = new System.Windows.Forms.Label();
            label36 = new System.Windows.Forms.Label();
            label37 = new System.Windows.Forms.Label();
            label38 = new System.Windows.Forms.Label();
            label39 = new System.Windows.Forms.Label();
            label40 = new System.Windows.Forms.Label();
            label41 = new System.Windows.Forms.Label();
            checkBox28 = new System.Windows.Forms.CheckBox();
            checkBox29 = new System.Windows.Forms.CheckBox();
            checkBox30 = new System.Windows.Forms.CheckBox();
            checkBox31 = new System.Windows.Forms.CheckBox();
            checkBox32 = new System.Windows.Forms.CheckBox();
            checkBox33 = new System.Windows.Forms.CheckBox();
            checkBox34 = new System.Windows.Forms.CheckBox();
            checkBox35 = new System.Windows.Forms.CheckBox();
            checkBox36 = new System.Windows.Forms.CheckBox();
            tabPagePoem = new System.Windows.Forms.TabPage();
            pictureBox37 = new System.Windows.Forms.PictureBox();
            pictureBox38 = new System.Windows.Forms.PictureBox();
            pictureBox39 = new System.Windows.Forms.PictureBox();
            pictureBox40 = new System.Windows.Forms.PictureBox();
            pictureBox41 = new System.Windows.Forms.PictureBox();
            pictureBox42 = new System.Windows.Forms.PictureBox();
            pictureBox43 = new System.Windows.Forms.PictureBox();
            pictureBox44 = new System.Windows.Forms.PictureBox();
            pictureBox45 = new System.Windows.Forms.PictureBox();
            label43 = new System.Windows.Forms.Label();
            label44 = new System.Windows.Forms.Label();
            label45 = new System.Windows.Forms.Label();
            label46 = new System.Windows.Forms.Label();
            label47 = new System.Windows.Forms.Label();
            label48 = new System.Windows.Forms.Label();
            label49 = new System.Windows.Forms.Label();
            label50 = new System.Windows.Forms.Label();
            label51 = new System.Windows.Forms.Label();
            checkBox37 = new System.Windows.Forms.CheckBox();
            checkBox38 = new System.Windows.Forms.CheckBox();
            checkBox39 = new System.Windows.Forms.CheckBox();
            checkBox40 = new System.Windows.Forms.CheckBox();
            checkBox41 = new System.Windows.Forms.CheckBox();
            checkBox42 = new System.Windows.Forms.CheckBox();
            checkBox43 = new System.Windows.Forms.CheckBox();
            checkBox44 = new System.Windows.Forms.CheckBox();
            checkBox45 = new System.Windows.Forms.CheckBox();
            tabPageDevelope = new System.Windows.Forms.TabPage();
            pictureBox46 = new System.Windows.Forms.PictureBox();
            pictureBox47 = new System.Windows.Forms.PictureBox();
            pictureBox48 = new System.Windows.Forms.PictureBox();
            pictureBox49 = new System.Windows.Forms.PictureBox();
            pictureBox50 = new System.Windows.Forms.PictureBox();
            pictureBox51 = new System.Windows.Forms.PictureBox();
            pictureBox52 = new System.Windows.Forms.PictureBox();
            pictureBox53 = new System.Windows.Forms.PictureBox();
            pictureBox54 = new System.Windows.Forms.PictureBox();
            label53 = new System.Windows.Forms.Label();
            label54 = new System.Windows.Forms.Label();
            label55 = new System.Windows.Forms.Label();
            label56 = new System.Windows.Forms.Label();
            label57 = new System.Windows.Forms.Label();
            label58 = new System.Windows.Forms.Label();
            label59 = new System.Windows.Forms.Label();
            label60 = new System.Windows.Forms.Label();
            label61 = new System.Windows.Forms.Label();
            checkBox46 = new System.Windows.Forms.CheckBox();
            checkBox47 = new System.Windows.Forms.CheckBox();
            checkBox48 = new System.Windows.Forms.CheckBox();
            checkBox49 = new System.Windows.Forms.CheckBox();
            checkBox50 = new System.Windows.Forms.CheckBox();
            checkBox51 = new System.Windows.Forms.CheckBox();
            checkBox52 = new System.Windows.Forms.CheckBox();
            checkBox53 = new System.Windows.Forms.CheckBox();
            checkBox54 = new System.Windows.Forms.CheckBox();
            tabPageNew = new System.Windows.Forms.TabPage();
            tabControl4 = new System.Windows.Forms.TabControl();
            tabPage1 = new System.Windows.Forms.TabPage();
            pictureBox55 = new System.Windows.Forms.PictureBox();
            pictureBox56 = new System.Windows.Forms.PictureBox();
            pictureBox57 = new System.Windows.Forms.PictureBox();
            pictureBox58 = new System.Windows.Forms.PictureBox();
            pictureBox59 = new System.Windows.Forms.PictureBox();
            pictureBox60 = new System.Windows.Forms.PictureBox();
            pictureBox61 = new System.Windows.Forms.PictureBox();
            pictureBox62 = new System.Windows.Forms.PictureBox();
            pictureBox63 = new System.Windows.Forms.PictureBox();
            label42 = new System.Windows.Forms.Label();
            label52 = new System.Windows.Forms.Label();
            label62 = new System.Windows.Forms.Label();
            label63 = new System.Windows.Forms.Label();
            label64 = new System.Windows.Forms.Label();
            label65 = new System.Windows.Forms.Label();
            label66 = new System.Windows.Forms.Label();
            label67 = new System.Windows.Forms.Label();
            label68 = new System.Windows.Forms.Label();
            checkBox55 = new System.Windows.Forms.CheckBox();
            checkBox56 = new System.Windows.Forms.CheckBox();
            checkBox57 = new System.Windows.Forms.CheckBox();
            checkBox58 = new System.Windows.Forms.CheckBox();
            checkBox59 = new System.Windows.Forms.CheckBox();
            checkBox60 = new System.Windows.Forms.CheckBox();
            checkBox61 = new System.Windows.Forms.CheckBox();
            checkBox62 = new System.Windows.Forms.CheckBox();
            checkBox63 = new System.Windows.Forms.CheckBox();
            label32 = new System.Windows.Forms.Label();
            tabPage2 = new System.Windows.Forms.TabPage();
            pictureBox70 = new System.Windows.Forms.PictureBox();
            pictureBox64 = new System.Windows.Forms.PictureBox();
            pictureBox69 = new System.Windows.Forms.PictureBox();
            pictureBox67 = new System.Windows.Forms.PictureBox();
            pictureBox66 = new System.Windows.Forms.PictureBox();
            pictureBox68 = new System.Windows.Forms.PictureBox();
            pictureBox65 = new System.Windows.Forms.PictureBox();
            pictureBox71 = new System.Windows.Forms.PictureBox();
            label73 = new System.Windows.Forms.Label();
            pictureBox72 = new System.Windows.Forms.PictureBox();
            label71 = new System.Windows.Forms.Label();
            label69 = new System.Windows.Forms.Label();
            label72 = new System.Windows.Forms.Label();
            label70 = new System.Windows.Forms.Label();
            label74 = new System.Windows.Forms.Label();
            label75 = new System.Windows.Forms.Label();
            label76 = new System.Windows.Forms.Label();
            checkBox67 = new System.Windows.Forms.CheckBox();
            label77 = new System.Windows.Forms.Label();
            checkBox66 = new System.Windows.Forms.CheckBox();
            checkBox68 = new System.Windows.Forms.CheckBox();
            checkBox65 = new System.Windows.Forms.CheckBox();
            checkBox64 = new System.Windows.Forms.CheckBox();
            checkBox69 = new System.Windows.Forms.CheckBox();
            checkBox70 = new System.Windows.Forms.CheckBox();
            checkBox71 = new System.Windows.Forms.CheckBox();
            checkBox72 = new System.Windows.Forms.CheckBox();
            label78 = new System.Windows.Forms.Label();
            listView1 = new System.Windows.Forms.ListView();
            bookName = new System.Windows.Forms.ColumnHeader();
            bookPrice = new System.Windows.Forms.ColumnHeader();
            bookMany = new System.Windows.Forms.ColumnHeader();
            label11 = new System.Windows.Forms.Label();
            textBox_price = new System.Windows.Forms.TextBox();
            btn_Initial = new System.Windows.Forms.Button();
            button1 = new System.Windows.Forms.Button();
            textBox2 = new System.Windows.Forms.TextBox();
            button2 = new System.Windows.Forms.Button();
            button3 = new System.Windows.Forms.Button();
            button4 = new System.Windows.Forms.Button();
            pictureBox73 = new System.Windows.Forms.PictureBox();
            button5 = new System.Windows.Forms.Button();
            button6 = new System.Windows.Forms.Button();
            button7 = new System.Windows.Forms.Button();
            button8 = new System.Windows.Forms.Button();
            pictureBox74 = new System.Windows.Forms.PictureBox();
            label79 = new System.Windows.Forms.Label();
            pictureBox75 = new System.Windows.Forms.PictureBox();
            tabControl1.SuspendLayout();
            tabPageBest.SuspendLayout();
            tabControl3.SuspendLayout();
            tabPageDay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            tabPageWeek.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            tabPageMonth.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox25).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox24).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox23).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox22).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox27).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox26).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox21).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).BeginInit();
            tabPageCate.SuspendLayout();
            tabControl2.SuspendLayout();
            tabPageNovel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox28).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox29).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox30).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox31).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox32).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox33).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox34).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox35).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox36).BeginInit();
            tabPagePoem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox37).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox38).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox39).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox40).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox41).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox42).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox43).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox44).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox45).BeginInit();
            tabPageDevelope.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox46).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox47).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox48).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox49).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox50).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox51).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox52).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox53).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox54).BeginInit();
            tabPageNew.SuspendLayout();
            tabControl4.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox55).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox56).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox57).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox58).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox59).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox60).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox61).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox62).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox63).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox70).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox64).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox69).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox67).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox66).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox68).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox65).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox71).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox72).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox73).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox74).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox75).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPageBest);
            tabControl1.Controls.Add(tabPageCate);
            tabControl1.Controls.Add(tabPageNew);
            tabControl1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            tabControl1.Location = new System.Drawing.Point(25, 106);
            tabControl1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new System.Drawing.Size(536, 672);
            tabControl1.TabIndex = 0;
            // 
            // tabPageBest
            // 
            tabPageBest.Controls.Add(tabControl3);
            tabPageBest.Location = new System.Drawing.Point(4, 32);
            tabPageBest.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPageBest.Name = "tabPageBest";
            tabPageBest.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPageBest.Size = new System.Drawing.Size(528, 636);
            tabPageBest.TabIndex = 0;
            tabPageBest.Text = "베스트셀러";
            tabPageBest.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            tabControl3.Controls.Add(tabPageDay);
            tabControl3.Controls.Add(tabPageWeek);
            tabControl3.Controls.Add(tabPageMonth);
            tabControl3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            tabControl3.Location = new System.Drawing.Point(-4, -4);
            tabControl3.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabControl3.Name = "tabControl3";
            tabControl3.SelectedIndex = 0;
            tabControl3.Size = new System.Drawing.Size(536, 643);
            tabControl3.TabIndex = 0;
            // 
            // tabPageDay
            // 
            tabPageDay.BackColor = System.Drawing.Color.PowderBlue;
            tabPageDay.Controls.Add(pictureBox9);
            tabPageDay.Controls.Add(pictureBox6);
            tabPageDay.Controls.Add(pictureBox3);
            tabPageDay.Controls.Add(pictureBox8);
            tabPageDay.Controls.Add(pictureBox7);
            tabPageDay.Controls.Add(pictureBox5);
            tabPageDay.Controls.Add(pictureBox4);
            tabPageDay.Controls.Add(pictureBox2);
            tabPageDay.Controls.Add(pictureBox1);
            tabPageDay.Controls.Add(label10);
            tabPageDay.Controls.Add(textBox1);
            tabPageDay.Controls.Add(label9);
            tabPageDay.Controls.Add(label8);
            tabPageDay.Controls.Add(label6);
            tabPageDay.Controls.Add(label5);
            tabPageDay.Controls.Add(label7);
            tabPageDay.Controls.Add(label3);
            tabPageDay.Controls.Add(label4);
            tabPageDay.Controls.Add(label2);
            tabPageDay.Controls.Add(label1);
            tabPageDay.Controls.Add(checkBox8);
            tabPageDay.Controls.Add(checkBox6);
            tabPageDay.Controls.Add(checkBox7);
            tabPageDay.Controls.Add(checkBox9);
            tabPageDay.Controls.Add(checkBox5);
            tabPageDay.Controls.Add(checkBox4);
            tabPageDay.Controls.Add(checkBox3);
            tabPageDay.Controls.Add(checkBox2);
            tabPageDay.Controls.Add(checkBox1);
            tabPageDay.Location = new System.Drawing.Point(4, 32);
            tabPageDay.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPageDay.Name = "tabPageDay";
            tabPageDay.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPageDay.Size = new System.Drawing.Size(528, 607);
            tabPageDay.TabIndex = 0;
            tabPageDay.Text = "일간";
            // 
            // pictureBox9
            // 
            pictureBox9.Image = Properties.Resources.희미한;
            pictureBox9.Location = new System.Drawing.Point(387, 412);
            pictureBox9.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new System.Drawing.Size(110, 122);
            pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 5;
            pictureBox9.TabStop = false;
            pictureBox9.Click += pictureBox9_Click;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.꿀벌;
            pictureBox6.Location = new System.Drawing.Point(387, 222);
            pictureBox6.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new System.Drawing.Size(110, 122);
            pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 5;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.세이노;
            pictureBox3.Location = new System.Drawing.Point(387, 57);
            pictureBox3.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new System.Drawing.Size(110, 122);
            pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 5;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = Properties.Resources.도둑;
            pictureBox8.Location = new System.Drawing.Point(200, 412);
            pictureBox8.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new System.Drawing.Size(110, 122);
            pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 5;
            pictureBox8.TabStop = false;
            pictureBox8.Click += pictureBox8_Click;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = Properties.Resources.역행자;
            pictureBox7.Location = new System.Drawing.Point(29, 412);
            pictureBox7.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new System.Drawing.Size(110, 122);
            pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 5;
            pictureBox7.TabStop = false;
            pictureBox7.Click += pictureBox7_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.도쿄;
            pictureBox5.Location = new System.Drawing.Point(204, 222);
            pictureBox5.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new System.Drawing.Size(110, 122);
            pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 5;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.문과;
            pictureBox4.Location = new System.Drawing.Point(29, 222);
            pictureBox4.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new System.Drawing.Size(110, 122);
            pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 5;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.늘;
            pictureBox2.Location = new System.Drawing.Point(204, 57);
            pictureBox2.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new System.Drawing.Size(110, 122);
            pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 5;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.최애의_아이;
            pictureBox1.Location = new System.Drawing.Point(29, 57);
            pictureBox1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(110, 122);
            pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new System.Drawing.Point(13, 11);
            label10.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(55, 23);
            label10.TabIndex = 4;
            label10.Text = "Today";
            // 
            // textBox1
            // 
            textBox1.BackColor = System.Drawing.Color.PowderBlue;
            textBox1.Location = new System.Drawing.Point(71, 8);
            textBox1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            textBox1.Name = "textBox1";
            textBox1.Size = new System.Drawing.Size(196, 31);
            textBox1.TabIndex = 3;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label9.Location = new System.Drawing.Point(383, 550);
            label9.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(41, 19);
            label9.TabIndex = 2;
            label9.Text = "6480";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label8.Location = new System.Drawing.Point(218, 550);
            label8.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(49, 19);
            label8.TabIndex = 2;
            label8.Text = "17000";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label6.Location = new System.Drawing.Point(383, 363);
            label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(41, 19);
            label6.TabIndex = 2;
            label6.Text = "6480";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(218, 363);
            label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(49, 19);
            label5.TabIndex = 2;
            label5.Text = "15000";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label7.Location = new System.Drawing.Point(45, 550);
            label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(49, 19);
            label7.TabIndex = 2;
            label7.Text = "17500";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label3.Location = new System.Drawing.Point(398, 195);
            label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(41, 19);
            label3.TabIndex = 2;
            label3.Text = "6480";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label4.Location = new System.Drawing.Point(45, 363);
            label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(41, 19);
            label4.TabIndex = 2;
            label4.Text = "6000";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(220, 195);
            label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(49, 19);
            label2.TabIndex = 2;
            label2.Text = "15000";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(45, 195);
            label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(41, 19);
            label1.TabIndex = 2;
            label1.Text = "6000";
            // 
            // checkBox8
            // 
            checkBox8.AutoSize = true;
            checkBox8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox8.Location = new System.Drawing.Point(366, 534);
            checkBox8.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox8.Name = "checkBox8";
            checkBox8.Size = new System.Drawing.Size(144, 23);
            checkBox8.TabIndex = 0;
            checkBox8.Text = "아주 희미한 빛으로도";
            checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            checkBox6.AutoSize = true;
            checkBox6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox6.Location = new System.Drawing.Point(366, 347);
            checkBox6.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox6.Name = "checkBox6";
            checkBox6.Size = new System.Drawing.Size(92, 23);
            checkBox6.TabIndex = 0;
            checkBox6.Text = "꿀벌의 예언";
            checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            checkBox7.AutoSize = true;
            checkBox7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox7.Location = new System.Drawing.Point(29, 534);
            checkBox7.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox7.Name = "checkBox7";
            checkBox7.Size = new System.Drawing.Size(64, 23);
            checkBox7.TabIndex = 0;
            checkBox7.Text = "역행자";
            checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            checkBox9.AutoSize = true;
            checkBox9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox9.Location = new System.Drawing.Point(199, 534);
            checkBox9.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox9.Name = "checkBox9";
            checkBox9.Size = new System.Drawing.Size(116, 23);
            checkBox9.TabIndex = 0;
            checkBox9.Text = "도둑맞은 집중력";
            checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox5.Location = new System.Drawing.Point(199, 347);
            checkBox5.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new System.Drawing.Size(120, 23);
            checkBox5.TabIndex = 0;
            checkBox5.Text = "도쿄 리번져스31";
            checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox4.Location = new System.Drawing.Point(29, 347);
            checkBox4.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new System.Drawing.Size(148, 23);
            checkBox4.TabIndex = 0;
            checkBox4.Text = "문과 남자의 과학 공부";
            checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox3.Location = new System.Drawing.Point(380, 179);
            checkBox3.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new System.Drawing.Size(116, 23);
            checkBox3.TabIndex = 0;
            checkBox3.Text = "세이노의 가르침";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox2.Location = new System.Drawing.Point(199, 179);
            checkBox2.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new System.Drawing.Size(148, 23);
            checkBox2.TabIndex = 0;
            checkBox2.Text = "늘 너의 편이 되어줄게";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox1.Location = new System.Drawing.Point(29, 179);
            checkBox1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new System.Drawing.Size(92, 23);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "최애의 아이";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // tabPageWeek
            // 
            tabPageWeek.BackColor = System.Drawing.Color.PowderBlue;
            tabPageWeek.Controls.Add(label80);
            tabPageWeek.Controls.Add(label12);
            tabPageWeek.Controls.Add(textBox5);
            tabPageWeek.Controls.Add(textBox3);
            tabPageWeek.Controls.Add(pictureBox18);
            tabPageWeek.Controls.Add(pictureBox17);
            tabPageWeek.Controls.Add(pictureBox16);
            tabPageWeek.Controls.Add(pictureBox15);
            tabPageWeek.Controls.Add(pictureBox13);
            tabPageWeek.Controls.Add(pictureBox14);
            tabPageWeek.Controls.Add(pictureBox11);
            tabPageWeek.Controls.Add(pictureBox12);
            tabPageWeek.Controls.Add(pictureBox10);
            tabPageWeek.Controls.Add(label13);
            tabPageWeek.Controls.Add(label14);
            tabPageWeek.Controls.Add(label15);
            tabPageWeek.Controls.Add(label16);
            tabPageWeek.Controls.Add(label17);
            tabPageWeek.Controls.Add(label18);
            tabPageWeek.Controls.Add(label19);
            tabPageWeek.Controls.Add(label20);
            tabPageWeek.Controls.Add(label21);
            tabPageWeek.Controls.Add(checkBox10);
            tabPageWeek.Controls.Add(checkBox11);
            tabPageWeek.Controls.Add(checkBox12);
            tabPageWeek.Controls.Add(checkBox13);
            tabPageWeek.Controls.Add(checkBox14);
            tabPageWeek.Controls.Add(checkBox15);
            tabPageWeek.Controls.Add(checkBox16);
            tabPageWeek.Controls.Add(checkBox17);
            tabPageWeek.Controls.Add(checkBox18);
            tabPageWeek.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            tabPageWeek.Location = new System.Drawing.Point(4, 32);
            tabPageWeek.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPageWeek.Name = "tabPageWeek";
            tabPageWeek.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPageWeek.Size = new System.Drawing.Size(528, 607);
            tabPageWeek.TabIndex = 1;
            tabPageWeek.Text = "주간";
            // 
            // label80
            // 
            label80.AutoSize = true;
            label80.Location = new System.Drawing.Point(286, 11);
            label80.Name = "label80";
            label80.Size = new System.Drawing.Size(17, 19);
            label80.TabIndex = 41;
            label80.Text = "~";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label12.Location = new System.Drawing.Point(13, 11);
            label12.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(55, 23);
            label12.TabIndex = 40;
            label12.Text = "Today";
            // 
            // textBox5
            // 
            textBox5.BackColor = System.Drawing.Color.PowderBlue;
            textBox5.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            textBox5.Location = new System.Drawing.Point(317, 7);
            textBox5.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            textBox5.Name = "textBox5";
            textBox5.Size = new System.Drawing.Size(196, 31);
            textBox5.TabIndex = 39;
            // 
            // textBox3
            // 
            textBox3.BackColor = System.Drawing.Color.PowderBlue;
            textBox3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            textBox3.Location = new System.Drawing.Point(71, 8);
            textBox3.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            textBox3.Name = "textBox3";
            textBox3.Size = new System.Drawing.Size(196, 31);
            textBox3.TabIndex = 39;
            // 
            // pictureBox18
            // 
            pictureBox18.Image = Properties.Resources.나는;
            pictureBox18.Location = new System.Drawing.Point(384, 413);
            pictureBox18.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox18.Name = "pictureBox18";
            pictureBox18.Size = new System.Drawing.Size(110, 122);
            pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox18.TabIndex = 37;
            pictureBox18.TabStop = false;
            pictureBox18.Click += pictureBox18_Click;
            // 
            // pictureBox17
            // 
            pictureBox17.Image = Properties.Resources.메리골드;
            pictureBox17.Location = new System.Drawing.Point(212, 413);
            pictureBox17.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox17.Name = "pictureBox17";
            pictureBox17.Size = new System.Drawing.Size(110, 122);
            pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox17.TabIndex = 37;
            pictureBox17.TabStop = false;
            pictureBox17.Click += pictureBox17_Click;
            // 
            // pictureBox16
            // 
            pictureBox16.Image = Properties.Resources.죽을때;
            pictureBox16.Location = new System.Drawing.Point(31, 413);
            pictureBox16.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox16.Name = "pictureBox16";
            pictureBox16.Size = new System.Drawing.Size(110, 122);
            pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox16.TabIndex = 37;
            pictureBox16.TabStop = false;
            pictureBox16.Click += pictureBox16_Click;
            // 
            // pictureBox15
            // 
            pictureBox15.Image = Properties.Resources.하늘;
            pictureBox15.Location = new System.Drawing.Point(31, 228);
            pictureBox15.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox15.Name = "pictureBox15";
            pictureBox15.Size = new System.Drawing.Size(110, 122);
            pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox15.TabIndex = 37;
            pictureBox15.TabStop = false;
            pictureBox15.Click += pictureBox15_Click;
            // 
            // pictureBox13
            // 
            pictureBox13.Image = Properties.Resources.도둑;
            pictureBox13.Location = new System.Drawing.Point(212, 228);
            pictureBox13.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new System.Drawing.Size(110, 122);
            pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox13.TabIndex = 37;
            pictureBox13.TabStop = false;
            pictureBox13.Click += pictureBox13_Click;
            // 
            // pictureBox14
            // 
            pictureBox14.Image = Properties.Resources.최애의_아이;
            pictureBox14.Location = new System.Drawing.Point(382, 228);
            pictureBox14.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new System.Drawing.Size(110, 122);
            pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox14.TabIndex = 38;
            pictureBox14.TabStop = false;
            pictureBox14.Click += pictureBox14_Click;
            // 
            // pictureBox11
            // 
            pictureBox11.Image = Properties.Resources.역행자;
            pictureBox11.Location = new System.Drawing.Point(382, 58);
            pictureBox11.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new System.Drawing.Size(110, 122);
            pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox11.TabIndex = 35;
            pictureBox11.TabStop = false;
            pictureBox11.Click += pictureBox11_Click;
            // 
            // pictureBox12
            // 
            pictureBox12.Image = Properties.Resources.문과;
            pictureBox12.Location = new System.Drawing.Point(212, 58);
            pictureBox12.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new System.Drawing.Size(110, 122);
            pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox12.TabIndex = 36;
            pictureBox12.TabStop = false;
            pictureBox12.Click += pictureBox12_Click;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = Properties.Resources.세이노;
            pictureBox10.Location = new System.Drawing.Point(31, 58);
            pictureBox10.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new System.Drawing.Size(110, 122);
            pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 34;
            pictureBox10.TabStop = false;
            pictureBox10.Click += pictureBox10_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label13.Location = new System.Drawing.Point(386, 553);
            label13.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(49, 19);
            label13.TabIndex = 31;
            label13.Text = "15700";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label14.Location = new System.Drawing.Point(220, 553);
            label14.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(49, 19);
            label14.TabIndex = 30;
            label14.Text = "13500";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label15.Location = new System.Drawing.Point(387, 370);
            label15.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(41, 19);
            label15.TabIndex = 29;
            label15.Text = "6000";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label16.Location = new System.Drawing.Point(220, 370);
            label16.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label16.Name = "label16";
            label16.Size = new System.Drawing.Size(49, 19);
            label16.TabIndex = 28;
            label16.Text = "15000";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label17.Location = new System.Drawing.Point(47, 553);
            label17.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label17.Name = "label17";
            label17.Size = new System.Drawing.Size(49, 19);
            label17.TabIndex = 27;
            label17.Text = "15000";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label18.Location = new System.Drawing.Point(387, 197);
            label18.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label18.Name = "label18";
            label18.Size = new System.Drawing.Size(49, 19);
            label18.TabIndex = 26;
            label18.Text = "17500";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label19.Location = new System.Drawing.Point(47, 370);
            label19.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label19.Name = "label19";
            label19.Size = new System.Drawing.Size(49, 19);
            label19.TabIndex = 25;
            label19.Text = "16000";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label20.Location = new System.Drawing.Point(220, 197);
            label20.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label20.Name = "label20";
            label20.Size = new System.Drawing.Size(49, 19);
            label20.TabIndex = 24;
            label20.Text = "15000";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label21.Location = new System.Drawing.Point(47, 197);
            label21.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label21.Name = "label21";
            label21.Size = new System.Drawing.Size(41, 19);
            label21.TabIndex = 23;
            label21.Text = "6480";
            // 
            // checkBox10
            // 
            checkBox10.AutoSize = true;
            checkBox10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox10.Location = new System.Drawing.Point(370, 537);
            checkBox10.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox10.Name = "checkBox10";
            checkBox10.Size = new System.Drawing.Size(136, 23);
            checkBox10.TabIndex = 12;
            checkBox10.Text = "나는 너랑 노는 게...";
            checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            checkBox11.AutoSize = true;
            checkBox11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox11.Location = new System.Drawing.Point(360, 352);
            checkBox11.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox11.Name = "checkBox11";
            checkBox11.Size = new System.Drawing.Size(92, 23);
            checkBox11.TabIndex = 11;
            checkBox11.Text = "최애의 아이";
            checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            checkBox12.AutoSize = true;
            checkBox12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox12.Location = new System.Drawing.Point(31, 537);
            checkBox12.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox12.Name = "checkBox12";
            checkBox12.Size = new System.Drawing.Size(132, 23);
            checkBox12.TabIndex = 10;
            checkBox12.Text = "나는 죽을 때까지...";
            checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            checkBox13.AutoSize = true;
            checkBox13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox13.Location = new System.Drawing.Point(200, 537);
            checkBox13.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox13.Name = "checkBox13";
            checkBox13.Size = new System.Drawing.Size(144, 23);
            checkBox13.TabIndex = 9;
            checkBox13.Text = "메리골드 마음 세탁소";
            checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            checkBox14.AutoSize = true;
            checkBox14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox14.Location = new System.Drawing.Point(200, 352);
            checkBox14.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox14.Name = "checkBox14";
            checkBox14.Size = new System.Drawing.Size(116, 23);
            checkBox14.TabIndex = 8;
            checkBox14.Text = "도둑맞은 집중력";
            checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            checkBox15.AutoSize = true;
            checkBox15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox15.Location = new System.Drawing.Point(31, 352);
            checkBox15.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox15.Name = "checkBox15";
            checkBox15.Size = new System.Drawing.Size(144, 23);
            checkBox15.TabIndex = 7;
            checkBox15.Text = "하늘과 바람과 별과...";
            checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            checkBox16.AutoSize = true;
            checkBox16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox16.Location = new System.Drawing.Point(370, 180);
            checkBox16.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox16.Name = "checkBox16";
            checkBox16.Size = new System.Drawing.Size(64, 23);
            checkBox16.TabIndex = 6;
            checkBox16.Text = "역행자";
            checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox17
            // 
            checkBox17.AutoSize = true;
            checkBox17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox17.Location = new System.Drawing.Point(200, 180);
            checkBox17.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox17.Name = "checkBox17";
            checkBox17.Size = new System.Drawing.Size(148, 23);
            checkBox17.TabIndex = 13;
            checkBox17.Text = "문과 남자의 과학 공부";
            checkBox17.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            checkBox18.AutoSize = true;
            checkBox18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox18.Location = new System.Drawing.Point(31, 180);
            checkBox18.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox18.Name = "checkBox18";
            checkBox18.Size = new System.Drawing.Size(116, 23);
            checkBox18.TabIndex = 5;
            checkBox18.Text = "세이노의 가르침";
            checkBox18.UseVisualStyleBackColor = true;
            // 
            // tabPageMonth
            // 
            tabPageMonth.BackColor = System.Drawing.Color.PowderBlue;
            tabPageMonth.Controls.Add(pictureBox25);
            tabPageMonth.Controls.Add(pictureBox24);
            tabPageMonth.Controls.Add(pictureBox23);
            tabPageMonth.Controls.Add(pictureBox22);
            tabPageMonth.Controls.Add(pictureBox20);
            tabPageMonth.Controls.Add(pictureBox27);
            tabPageMonth.Controls.Add(pictureBox26);
            tabPageMonth.Controls.Add(pictureBox21);
            tabPageMonth.Controls.Add(pictureBox19);
            tabPageMonth.Controls.Add(label22);
            tabPageMonth.Controls.Add(textBox4);
            tabPageMonth.Controls.Add(label23);
            tabPageMonth.Controls.Add(label24);
            tabPageMonth.Controls.Add(label25);
            tabPageMonth.Controls.Add(label26);
            tabPageMonth.Controls.Add(label27);
            tabPageMonth.Controls.Add(label28);
            tabPageMonth.Controls.Add(label29);
            tabPageMonth.Controls.Add(label30);
            tabPageMonth.Controls.Add(label31);
            tabPageMonth.Controls.Add(checkBox19);
            tabPageMonth.Controls.Add(checkBox20);
            tabPageMonth.Controls.Add(checkBox21);
            tabPageMonth.Controls.Add(checkBox22);
            tabPageMonth.Controls.Add(checkBox23);
            tabPageMonth.Controls.Add(checkBox24);
            tabPageMonth.Controls.Add(checkBox25);
            tabPageMonth.Controls.Add(checkBox26);
            tabPageMonth.Controls.Add(checkBox27);
            tabPageMonth.Location = new System.Drawing.Point(4, 32);
            tabPageMonth.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPageMonth.Name = "tabPageMonth";
            tabPageMonth.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPageMonth.Size = new System.Drawing.Size(528, 607);
            tabPageMonth.TabIndex = 2;
            tabPageMonth.Text = "월간";
            // 
            // pictureBox25
            // 
            pictureBox25.Image = Properties.Resources.사장;
            pictureBox25.Location = new System.Drawing.Point(217, 226);
            pictureBox25.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox25.Name = "pictureBox25";
            pictureBox25.Size = new System.Drawing.Size(110, 122);
            pictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox25.TabIndex = 67;
            pictureBox25.TabStop = false;
            pictureBox25.Click += pictureBox25_Click;
            // 
            // pictureBox24
            // 
            pictureBox24.Image = Properties.Resources.유연함;
            pictureBox24.Location = new System.Drawing.Point(213, 411);
            pictureBox24.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox24.Name = "pictureBox24";
            pictureBox24.Size = new System.Drawing.Size(110, 122);
            pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox24.TabIndex = 67;
            pictureBox24.TabStop = false;
            pictureBox24.Click += pictureBox24_Click;
            // 
            // pictureBox23
            // 
            pictureBox23.Image = Properties.Resources.메리골드;
            pictureBox23.Location = new System.Drawing.Point(32, 411);
            pictureBox23.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox23.Name = "pictureBox23";
            pictureBox23.Size = new System.Drawing.Size(110, 122);
            pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox23.TabIndex = 67;
            pictureBox23.TabStop = false;
            pictureBox23.Click += pictureBox23_Click;
            // 
            // pictureBox22
            // 
            pictureBox22.Image = Properties.Resources.도둑;
            pictureBox22.Location = new System.Drawing.Point(32, 226);
            pictureBox22.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox22.Name = "pictureBox22";
            pictureBox22.Size = new System.Drawing.Size(110, 122);
            pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox22.TabIndex = 66;
            pictureBox22.TabStop = false;
            pictureBox22.Click += pictureBox22_Click;
            // 
            // pictureBox20
            // 
            pictureBox20.Image = Properties.Resources.역행자;
            pictureBox20.Location = new System.Drawing.Point(213, 56);
            pictureBox20.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox20.Name = "pictureBox20";
            pictureBox20.Size = new System.Drawing.Size(110, 122);
            pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox20.TabIndex = 64;
            pictureBox20.TabStop = false;
            pictureBox20.Click += pictureBox20_Click;
            // 
            // pictureBox27
            // 
            pictureBox27.Image = Properties.Resources.one;
            pictureBox27.Location = new System.Drawing.Point(383, 411);
            pictureBox27.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox27.Name = "pictureBox27";
            pictureBox27.Size = new System.Drawing.Size(110, 122);
            pictureBox27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox27.TabIndex = 65;
            pictureBox27.TabStop = false;
            pictureBox27.Click += pictureBox27_Click;
            // 
            // pictureBox26
            // 
            pictureBox26.Image = Properties.Resources.모든삶;
            pictureBox26.Location = new System.Drawing.Point(383, 226);
            pictureBox26.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox26.Name = "pictureBox26";
            pictureBox26.Size = new System.Drawing.Size(110, 122);
            pictureBox26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox26.TabIndex = 65;
            pictureBox26.TabStop = false;
            pictureBox26.Click += pictureBox26_Click;
            // 
            // pictureBox21
            // 
            pictureBox21.Image = Properties.Resources.문과;
            pictureBox21.Location = new System.Drawing.Point(383, 56);
            pictureBox21.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox21.Name = "pictureBox21";
            pictureBox21.Size = new System.Drawing.Size(110, 122);
            pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox21.TabIndex = 65;
            pictureBox21.TabStop = false;
            pictureBox21.Click += pictureBox21_Click;
            // 
            // pictureBox19
            // 
            pictureBox19.Image = Properties.Resources.세이노;
            pictureBox19.Location = new System.Drawing.Point(32, 56);
            pictureBox19.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox19.Name = "pictureBox19";
            pictureBox19.Size = new System.Drawing.Size(110, 122);
            pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox19.TabIndex = 63;
            pictureBox19.TabStop = false;
            pictureBox19.Click += pictureBox19_Click;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new System.Drawing.Point(13, 11);
            label22.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label22.Name = "label22";
            label22.Size = new System.Drawing.Size(55, 23);
            label22.TabIndex = 62;
            label22.Text = "Today";
            // 
            // textBox4
            // 
            textBox4.BackColor = System.Drawing.Color.PowderBlue;
            textBox4.Location = new System.Drawing.Point(70, 7);
            textBox4.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            textBox4.Name = "textBox4";
            textBox4.Size = new System.Drawing.Size(196, 31);
            textBox4.TabIndex = 61;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label23.Location = new System.Drawing.Point(387, 553);
            label23.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label23.Name = "label23";
            label23.Size = new System.Drawing.Size(49, 19);
            label23.TabIndex = 60;
            label23.Text = "12600";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label24.Location = new System.Drawing.Point(221, 553);
            label24.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label24.Name = "label24";
            label24.Size = new System.Drawing.Size(49, 19);
            label24.TabIndex = 59;
            label24.Text = "19800";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label25.Location = new System.Drawing.Point(387, 366);
            label25.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label25.Name = "label25";
            label25.Size = new System.Drawing.Size(49, 19);
            label25.TabIndex = 58;
            label25.Text = "15100";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label26.Location = new System.Drawing.Point(221, 366);
            label26.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label26.Name = "label26";
            label26.Size = new System.Drawing.Size(49, 19);
            label26.TabIndex = 57;
            label26.Text = "22500";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label27.Location = new System.Drawing.Point(48, 553);
            label27.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label27.Name = "label27";
            label27.Size = new System.Drawing.Size(49, 19);
            label27.TabIndex = 56;
            label27.Text = "13500";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label28.Location = new System.Drawing.Point(387, 194);
            label28.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label28.Name = "label28";
            label28.Size = new System.Drawing.Size(49, 19);
            label28.TabIndex = 55;
            label28.Text = "15700";
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label29.Location = new System.Drawing.Point(48, 366);
            label29.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label29.Name = "label29";
            label29.Size = new System.Drawing.Size(49, 19);
            label29.TabIndex = 54;
            label29.Text = "16920";
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label30.Location = new System.Drawing.Point(221, 194);
            label30.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label30.Name = "label30";
            label30.Size = new System.Drawing.Size(49, 19);
            label30.TabIndex = 53;
            label30.Text = "17500";
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label31.Location = new System.Drawing.Point(47, 194);
            label31.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label31.Name = "label31";
            label31.Size = new System.Drawing.Size(41, 19);
            label31.TabIndex = 52;
            label31.Text = "6480";
            // 
            // checkBox19
            // 
            checkBox19.AutoSize = true;
            checkBox19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox19.Location = new System.Drawing.Point(371, 535);
            checkBox19.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox19.Name = "checkBox19";
            checkBox19.Size = new System.Drawing.Size(127, 23);
            checkBox19.TabIndex = 41;
            checkBox19.Text = "The One Thing";
            checkBox19.UseVisualStyleBackColor = true;
            // 
            // checkBox20
            // 
            checkBox20.AutoSize = true;
            checkBox20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox20.Location = new System.Drawing.Point(371, 350);
            checkBox20.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox20.Name = "checkBox20";
            checkBox20.Size = new System.Drawing.Size(120, 23);
            checkBox20.TabIndex = 40;
            checkBox20.Text = "모든 삶은 흐른다";
            checkBox20.UseVisualStyleBackColor = true;
            // 
            // checkBox21
            // 
            checkBox21.AutoSize = true;
            checkBox21.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox21.Location = new System.Drawing.Point(32, 535);
            checkBox21.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox21.Name = "checkBox21";
            checkBox21.Size = new System.Drawing.Size(144, 23);
            checkBox21.TabIndex = 39;
            checkBox21.Text = "메리골드 마음 세탁소";
            checkBox21.UseVisualStyleBackColor = true;
            // 
            // checkBox22
            // 
            checkBox22.AutoSize = true;
            checkBox22.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox22.Location = new System.Drawing.Point(201, 535);
            checkBox22.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox22.Name = "checkBox22";
            checkBox22.Size = new System.Drawing.Size(92, 23);
            checkBox22.TabIndex = 38;
            checkBox22.Text = "유연함의 힘";
            checkBox22.UseVisualStyleBackColor = true;
            // 
            // checkBox23
            // 
            checkBox23.AutoSize = true;
            checkBox23.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox23.Location = new System.Drawing.Point(201, 350);
            checkBox23.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox23.Name = "checkBox23";
            checkBox23.Size = new System.Drawing.Size(88, 23);
            checkBox23.TabIndex = 37;
            checkBox23.Text = "사장학개론";
            checkBox23.UseVisualStyleBackColor = true;
            // 
            // checkBox24
            // 
            checkBox24.AutoSize = true;
            checkBox24.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox24.Location = new System.Drawing.Point(32, 350);
            checkBox24.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox24.Name = "checkBox24";
            checkBox24.Size = new System.Drawing.Size(116, 23);
            checkBox24.TabIndex = 36;
            checkBox24.Text = "도둑맞은 집중력";
            checkBox24.UseVisualStyleBackColor = true;
            // 
            // checkBox25
            // 
            checkBox25.AutoSize = true;
            checkBox25.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox25.Location = new System.Drawing.Point(371, 178);
            checkBox25.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox25.Name = "checkBox25";
            checkBox25.Size = new System.Drawing.Size(148, 23);
            checkBox25.TabIndex = 35;
            checkBox25.Text = "문과 남자의 과학 공부";
            checkBox25.UseVisualStyleBackColor = true;
            // 
            // checkBox26
            // 
            checkBox26.AutoSize = true;
            checkBox26.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox26.Location = new System.Drawing.Point(201, 178);
            checkBox26.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox26.Name = "checkBox26";
            checkBox26.Size = new System.Drawing.Size(64, 23);
            checkBox26.TabIndex = 42;
            checkBox26.Text = "역행자";
            checkBox26.UseVisualStyleBackColor = true;
            // 
            // checkBox27
            // 
            checkBox27.AutoSize = true;
            checkBox27.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox27.Location = new System.Drawing.Point(32, 178);
            checkBox27.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox27.Name = "checkBox27";
            checkBox27.Size = new System.Drawing.Size(116, 23);
            checkBox27.TabIndex = 34;
            checkBox27.Text = "세이노의 가르침";
            checkBox27.UseVisualStyleBackColor = true;
            // 
            // tabPageCate
            // 
            tabPageCate.Controls.Add(tabControl2);
            tabPageCate.Location = new System.Drawing.Point(4, 32);
            tabPageCate.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPageCate.Name = "tabPageCate";
            tabPageCate.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPageCate.Size = new System.Drawing.Size(528, 636);
            tabPageCate.TabIndex = 1;
            tabPageCate.Text = "카테고리";
            tabPageCate.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            tabControl2.Controls.Add(tabPageNovel);
            tabControl2.Controls.Add(tabPagePoem);
            tabControl2.Controls.Add(tabPageDevelope);
            tabControl2.Location = new System.Drawing.Point(0, 4);
            tabControl2.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabControl2.Name = "tabControl2";
            tabControl2.SelectedIndex = 0;
            tabControl2.Size = new System.Drawing.Size(722, 631);
            tabControl2.TabIndex = 0;
            // 
            // tabPageNovel
            // 
            tabPageNovel.BackColor = System.Drawing.Color.PowderBlue;
            tabPageNovel.Controls.Add(pictureBox28);
            tabPageNovel.Controls.Add(pictureBox29);
            tabPageNovel.Controls.Add(pictureBox30);
            tabPageNovel.Controls.Add(pictureBox31);
            tabPageNovel.Controls.Add(pictureBox32);
            tabPageNovel.Controls.Add(pictureBox33);
            tabPageNovel.Controls.Add(pictureBox34);
            tabPageNovel.Controls.Add(pictureBox35);
            tabPageNovel.Controls.Add(pictureBox36);
            tabPageNovel.Controls.Add(label33);
            tabPageNovel.Controls.Add(label34);
            tabPageNovel.Controls.Add(label35);
            tabPageNovel.Controls.Add(label36);
            tabPageNovel.Controls.Add(label37);
            tabPageNovel.Controls.Add(label38);
            tabPageNovel.Controls.Add(label39);
            tabPageNovel.Controls.Add(label40);
            tabPageNovel.Controls.Add(label41);
            tabPageNovel.Controls.Add(checkBox28);
            tabPageNovel.Controls.Add(checkBox29);
            tabPageNovel.Controls.Add(checkBox30);
            tabPageNovel.Controls.Add(checkBox31);
            tabPageNovel.Controls.Add(checkBox32);
            tabPageNovel.Controls.Add(checkBox33);
            tabPageNovel.Controls.Add(checkBox34);
            tabPageNovel.Controls.Add(checkBox35);
            tabPageNovel.Controls.Add(checkBox36);
            tabPageNovel.Location = new System.Drawing.Point(4, 32);
            tabPageNovel.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPageNovel.Name = "tabPageNovel";
            tabPageNovel.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPageNovel.Size = new System.Drawing.Size(714, 595);
            tabPageNovel.TabIndex = 0;
            tabPageNovel.Text = "소설";
            // 
            // pictureBox28
            // 
            pictureBox28.Image = Properties.Resources.구름;
            pictureBox28.Location = new System.Drawing.Point(388, 400);
            pictureBox28.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox28.Name = "pictureBox28";
            pictureBox28.Size = new System.Drawing.Size(110, 122);
            pictureBox28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox28.TabIndex = 34;
            pictureBox28.TabStop = false;
            // 
            // pictureBox29
            // 
            pictureBox29.Image = Properties.Resources.너무나많은;
            pictureBox29.Location = new System.Drawing.Point(388, 215);
            pictureBox29.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox29.Name = "pictureBox29";
            pictureBox29.Size = new System.Drawing.Size(110, 122);
            pictureBox29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox29.TabIndex = 33;
            pictureBox29.TabStop = false;
            // 
            // pictureBox30
            // 
            pictureBox30.Image = Properties.Resources.게임;
            pictureBox30.Location = new System.Drawing.Point(388, 45);
            pictureBox30.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox30.Name = "pictureBox30";
            pictureBox30.Size = new System.Drawing.Size(110, 122);
            pictureBox30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox30.TabIndex = 32;
            pictureBox30.TabStop = false;
            pictureBox30.Click += pictureBox30_Click;
            // 
            // pictureBox31
            // 
            pictureBox31.Image = Properties.Resources.꽃;
            pictureBox31.Location = new System.Drawing.Point(207, 400);
            pictureBox31.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox31.Name = "pictureBox31";
            pictureBox31.Size = new System.Drawing.Size(110, 122);
            pictureBox31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox31.TabIndex = 31;
            pictureBox31.TabStop = false;
            // 
            // pictureBox32
            // 
            pictureBox32.Image = Properties.Resources.용;
            pictureBox32.Location = new System.Drawing.Point(24, 400);
            pictureBox32.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox32.Name = "pictureBox32";
            pictureBox32.Size = new System.Drawing.Size(110, 122);
            pictureBox32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox32.TabIndex = 30;
            pictureBox32.TabStop = false;
            // 
            // pictureBox33
            // 
            pictureBox33.Image = Properties.Resources.상점;
            pictureBox33.Location = new System.Drawing.Point(207, 215);
            pictureBox33.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox33.Name = "pictureBox33";
            pictureBox33.Size = new System.Drawing.Size(110, 122);
            pictureBox33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox33.TabIndex = 29;
            pictureBox33.TabStop = false;
            // 
            // pictureBox34
            // 
            pictureBox34.Image = Properties.Resources.좋은곳;
            pictureBox34.Location = new System.Drawing.Point(24, 215);
            pictureBox34.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox34.Name = "pictureBox34";
            pictureBox34.Size = new System.Drawing.Size(110, 122);
            pictureBox34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox34.TabIndex = 28;
            pictureBox34.TabStop = false;
            // 
            // pictureBox35
            // 
            pictureBox35.Image = Properties.Resources.제주도;
            pictureBox35.Location = new System.Drawing.Point(207, 45);
            pictureBox35.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox35.Name = "pictureBox35";
            pictureBox35.Size = new System.Drawing.Size(110, 122);
            pictureBox35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox35.TabIndex = 27;
            pictureBox35.TabStop = false;
            pictureBox35.Click += pictureBox35_Click;
            // 
            // pictureBox36
            // 
            pictureBox36.Image = Properties.Resources.건널목;
            pictureBox36.Location = new System.Drawing.Point(24, 45);
            pictureBox36.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox36.Name = "pictureBox36";
            pictureBox36.Size = new System.Drawing.Size(110, 122);
            pictureBox36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox36.TabIndex = 26;
            pictureBox36.TabStop = false;
            pictureBox36.Click += pictureBox36_Click;
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label33.Location = new System.Drawing.Point(382, 545);
            label33.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label33.Name = "label33";
            label33.Size = new System.Drawing.Size(49, 19);
            label33.TabIndex = 22;
            label33.Text = "13000";
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label34.Location = new System.Drawing.Point(216, 545);
            label34.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label34.Name = "label34";
            label34.Size = new System.Drawing.Size(49, 19);
            label34.TabIndex = 21;
            label34.Text = "16200";
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label35.Location = new System.Drawing.Point(382, 361);
            label35.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label35.Name = "label35";
            label35.Size = new System.Drawing.Size(49, 19);
            label35.TabIndex = 23;
            label35.Text = "14400";
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label36.Location = new System.Drawing.Point(216, 361);
            label36.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label36.Name = "label36";
            label36.Size = new System.Drawing.Size(49, 19);
            label36.TabIndex = 20;
            label36.Text = "15000";
            // 
            // label37
            // 
            label37.AutoSize = true;
            label37.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label37.Location = new System.Drawing.Point(43, 545);
            label37.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label37.Name = "label37";
            label37.Size = new System.Drawing.Size(49, 19);
            label37.TabIndex = 19;
            label37.Text = "15300";
            // 
            // label38
            // 
            label38.AutoSize = true;
            label38.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label38.Location = new System.Drawing.Point(384, 187);
            label38.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label38.Name = "label38";
            label38.Size = new System.Drawing.Size(49, 19);
            label38.TabIndex = 18;
            label38.Text = "15000";
            // 
            // label39
            // 
            label39.AutoSize = true;
            label39.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label39.Location = new System.Drawing.Point(43, 361);
            label39.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label39.Name = "label39";
            label39.Size = new System.Drawing.Size(49, 19);
            label39.TabIndex = 17;
            label39.Text = "14400";
            // 
            // label40
            // 
            label40.AutoSize = true;
            label40.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label40.Location = new System.Drawing.Point(218, 187);
            label40.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label40.Name = "label40";
            label40.Size = new System.Drawing.Size(49, 19);
            label40.TabIndex = 16;
            label40.Text = "45900";
            // 
            // label41
            // 
            label41.AutoSize = true;
            label41.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label41.Location = new System.Drawing.Point(46, 187);
            label41.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label41.Name = "label41";
            label41.Size = new System.Drawing.Size(49, 19);
            label41.TabIndex = 15;
            label41.Text = "15300";
            // 
            // checkBox28
            // 
            checkBox28.AutoSize = true;
            checkBox28.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox28.Location = new System.Drawing.Point(363, 527);
            checkBox28.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox28.Name = "checkBox28";
            checkBox28.Size = new System.Drawing.Size(112, 23);
            checkBox28.TabIndex = 13;
            checkBox28.Text = "구름해석전문가";
            checkBox28.UseVisualStyleBackColor = true;
            // 
            // checkBox29
            // 
            checkBox29.AutoSize = true;
            checkBox29.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox29.Location = new System.Drawing.Point(363, 342);
            checkBox29.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox29.Name = "checkBox29";
            checkBox29.Size = new System.Drawing.Size(132, 23);
            checkBox29.TabIndex = 12;
            checkBox29.Text = "너무나 많은 여름이";
            checkBox29.UseVisualStyleBackColor = true;
            // 
            // checkBox30
            // 
            checkBox30.AutoSize = true;
            checkBox30.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox30.Location = new System.Drawing.Point(27, 527);
            checkBox30.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox30.Name = "checkBox30";
            checkBox30.Size = new System.Drawing.Size(92, 23);
            checkBox30.TabIndex = 11;
            checkBox30.Text = "용의 만화경";
            checkBox30.UseVisualStyleBackColor = true;
            // 
            // checkBox31
            // 
            checkBox31.AutoSize = true;
            checkBox31.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox31.Location = new System.Drawing.Point(198, 527);
            checkBox31.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox31.Name = "checkBox31";
            checkBox31.Size = new System.Drawing.Size(132, 23);
            checkBox31.TabIndex = 10;
            checkBox31.Text = "꽃피는 산골 교향곡";
            checkBox31.UseVisualStyleBackColor = true;
            // 
            // checkBox32
            // 
            checkBox32.AutoSize = true;
            checkBox32.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox32.Location = new System.Drawing.Point(198, 342);
            checkBox32.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox32.Name = "checkBox32";
            checkBox32.Size = new System.Drawing.Size(148, 23);
            checkBox32.TabIndex = 9;
            checkBox32.Text = "비가 오면 열리는 상점";
            checkBox32.UseVisualStyleBackColor = true;
            // 
            // checkBox33
            // 
            checkBox33.AutoSize = true;
            checkBox33.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox33.Location = new System.Drawing.Point(27, 342);
            checkBox33.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox33.Name = "checkBox33";
            checkBox33.Size = new System.Drawing.Size(132, 23);
            checkBox33.TabIndex = 8;
            checkBox33.Text = "좋은 곳에서 만나요";
            checkBox33.UseVisualStyleBackColor = true;
            // 
            // checkBox34
            // 
            checkBox34.AutoSize = true;
            checkBox34.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox34.Location = new System.Drawing.Point(363, 170);
            checkBox34.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox34.Name = "checkBox34";
            checkBox34.Size = new System.Drawing.Size(128, 23);
            checkBox34.TabIndex = 7;
            checkBox34.Text = "매스커레이드 게임";
            checkBox34.UseVisualStyleBackColor = true;
            // 
            // checkBox35
            // 
            checkBox35.AutoSize = true;
            checkBox35.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox35.Location = new System.Drawing.Point(198, 170);
            checkBox35.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox35.Name = "checkBox35";
            checkBox35.Size = new System.Drawing.Size(116, 23);
            checkBox35.TabIndex = 14;
            checkBox35.Text = "제주도우다 세트";
            checkBox35.UseVisualStyleBackColor = true;
            // 
            // checkBox36
            // 
            checkBox36.AutoSize = true;
            checkBox36.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox36.Location = new System.Drawing.Point(27, 170);
            checkBox36.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox36.Name = "checkBox36";
            checkBox36.Size = new System.Drawing.Size(104, 23);
            checkBox36.TabIndex = 6;
            checkBox36.Text = "건널목의 유령";
            checkBox36.UseVisualStyleBackColor = true;
            // 
            // tabPagePoem
            // 
            tabPagePoem.BackColor = System.Drawing.Color.PowderBlue;
            tabPagePoem.Controls.Add(pictureBox37);
            tabPagePoem.Controls.Add(pictureBox38);
            tabPagePoem.Controls.Add(pictureBox39);
            tabPagePoem.Controls.Add(pictureBox40);
            tabPagePoem.Controls.Add(pictureBox41);
            tabPagePoem.Controls.Add(pictureBox42);
            tabPagePoem.Controls.Add(pictureBox43);
            tabPagePoem.Controls.Add(pictureBox44);
            tabPagePoem.Controls.Add(pictureBox45);
            tabPagePoem.Controls.Add(label43);
            tabPagePoem.Controls.Add(label44);
            tabPagePoem.Controls.Add(label45);
            tabPagePoem.Controls.Add(label46);
            tabPagePoem.Controls.Add(label47);
            tabPagePoem.Controls.Add(label48);
            tabPagePoem.Controls.Add(label49);
            tabPagePoem.Controls.Add(label50);
            tabPagePoem.Controls.Add(label51);
            tabPagePoem.Controls.Add(checkBox37);
            tabPagePoem.Controls.Add(checkBox38);
            tabPagePoem.Controls.Add(checkBox39);
            tabPagePoem.Controls.Add(checkBox40);
            tabPagePoem.Controls.Add(checkBox41);
            tabPagePoem.Controls.Add(checkBox42);
            tabPagePoem.Controls.Add(checkBox43);
            tabPagePoem.Controls.Add(checkBox44);
            tabPagePoem.Controls.Add(checkBox45);
            tabPagePoem.Location = new System.Drawing.Point(4, 24);
            tabPagePoem.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPagePoem.Name = "tabPagePoem";
            tabPagePoem.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPagePoem.Size = new System.Drawing.Size(714, 603);
            tabPagePoem.TabIndex = 1;
            tabPagePoem.Text = "시/에세이";
            // 
            // pictureBox37
            // 
            pictureBox37.Image = Properties.Resources.하지;
            pictureBox37.Location = new System.Drawing.Point(382, 401);
            pictureBox37.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox37.Name = "pictureBox37";
            pictureBox37.Size = new System.Drawing.Size(110, 122);
            pictureBox37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox37.TabIndex = 63;
            pictureBox37.TabStop = false;
            // 
            // pictureBox38
            // 
            pictureBox38.Image = Properties.Resources.어푸어푸;
            pictureBox38.Location = new System.Drawing.Point(382, 216);
            pictureBox38.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox38.Name = "pictureBox38";
            pictureBox38.Size = new System.Drawing.Size(110, 122);
            pictureBox38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox38.TabIndex = 62;
            pictureBox38.TabStop = false;
            // 
            // pictureBox39
            // 
            pictureBox39.Image = Properties.Resources.무임술차;
            pictureBox39.Location = new System.Drawing.Point(382, 46);
            pictureBox39.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox39.Name = "pictureBox39";
            pictureBox39.Size = new System.Drawing.Size(110, 122);
            pictureBox39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox39.TabIndex = 61;
            pictureBox39.TabStop = false;
            // 
            // pictureBox40
            // 
            pictureBox40.Image = Properties.Resources.귀;
            pictureBox40.Location = new System.Drawing.Point(201, 401);
            pictureBox40.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox40.Name = "pictureBox40";
            pictureBox40.Size = new System.Drawing.Size(110, 122);
            pictureBox40.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox40.TabIndex = 60;
            pictureBox40.TabStop = false;
            // 
            // pictureBox41
            // 
            pictureBox41.Image = Properties.Resources.소년;
            pictureBox41.Location = new System.Drawing.Point(18, 401);
            pictureBox41.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox41.Name = "pictureBox41";
            pictureBox41.Size = new System.Drawing.Size(110, 122);
            pictureBox41.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox41.TabIndex = 59;
            pictureBox41.TabStop = false;
            // 
            // pictureBox42
            // 
            pictureBox42.Image = Properties.Resources.결혼;
            pictureBox42.Location = new System.Drawing.Point(201, 216);
            pictureBox42.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox42.Name = "pictureBox42";
            pictureBox42.Size = new System.Drawing.Size(110, 122);
            pictureBox42.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox42.TabIndex = 58;
            pictureBox42.TabStop = false;
            // 
            // pictureBox43
            // 
            pictureBox43.Image = Properties.Resources.우리는;
            pictureBox43.Location = new System.Drawing.Point(18, 216);
            pictureBox43.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox43.Name = "pictureBox43";
            pictureBox43.Size = new System.Drawing.Size(110, 122);
            pictureBox43.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox43.TabIndex = 57;
            pictureBox43.TabStop = false;
            // 
            // pictureBox44
            // 
            pictureBox44.Image = Properties.Resources.늘;
            pictureBox44.Location = new System.Drawing.Point(201, 46);
            pictureBox44.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox44.Name = "pictureBox44";
            pictureBox44.Size = new System.Drawing.Size(110, 122);
            pictureBox44.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox44.TabIndex = 56;
            pictureBox44.TabStop = false;
            // 
            // pictureBox45
            // 
            pictureBox45.Image = Properties.Resources.나는;
            pictureBox45.Location = new System.Drawing.Point(18, 46);
            pictureBox45.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox45.Name = "pictureBox45";
            pictureBox45.Size = new System.Drawing.Size(110, 122);
            pictureBox45.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox45.TabIndex = 55;
            pictureBox45.TabStop = false;
            // 
            // label43
            // 
            label43.AutoSize = true;
            label43.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label43.Location = new System.Drawing.Point(382, 547);
            label43.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label43.Name = "label43";
            label43.Size = new System.Drawing.Size(49, 19);
            label43.TabIndex = 51;
            label43.Text = "15100";
            // 
            // label44
            // 
            label44.AutoSize = true;
            label44.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label44.Location = new System.Drawing.Point(216, 547);
            label44.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label44.Name = "label44";
            label44.Size = new System.Drawing.Size(49, 19);
            label44.TabIndex = 50;
            label44.Text = "20700";
            // 
            // label45
            // 
            label45.AutoSize = true;
            label45.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label45.Location = new System.Drawing.Point(382, 360);
            label45.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label45.Name = "label45";
            label45.Size = new System.Drawing.Size(49, 19);
            label45.TabIndex = 52;
            label45.Text = "14200";
            // 
            // label46
            // 
            label46.AutoSize = true;
            label46.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label46.Location = new System.Drawing.Point(216, 360);
            label46.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label46.Name = "label46";
            label46.Size = new System.Drawing.Size(49, 19);
            label46.TabIndex = 49;
            label46.Text = "17800";
            // 
            // label47
            // 
            label47.AutoSize = true;
            label47.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label47.Location = new System.Drawing.Point(43, 547);
            label47.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label47.Name = "label47";
            label47.Size = new System.Drawing.Size(49, 19);
            label47.TabIndex = 48;
            label47.Text = "16000";
            // 
            // label48
            // 
            label48.AutoSize = true;
            label48.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label48.Location = new System.Drawing.Point(384, 189);
            label48.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label48.Name = "label48";
            label48.Size = new System.Drawing.Size(49, 19);
            label48.TabIndex = 47;
            label48.Text = "15100";
            // 
            // label49
            // 
            label49.AutoSize = true;
            label49.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label49.Location = new System.Drawing.Point(43, 360);
            label49.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label49.Name = "label49";
            label49.Size = new System.Drawing.Size(49, 19);
            label49.TabIndex = 46;
            label49.Text = "15700";
            // 
            // label50
            // 
            label50.AutoSize = true;
            label50.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label50.Location = new System.Drawing.Point(218, 189);
            label50.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label50.Name = "label50";
            label50.Size = new System.Drawing.Size(49, 19);
            label50.TabIndex = 45;
            label50.Text = "15000";
            // 
            // label51
            // 
            label51.AutoSize = true;
            label51.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label51.Location = new System.Drawing.Point(46, 189);
            label51.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label51.Name = "label51";
            label51.Size = new System.Drawing.Size(49, 19);
            label51.TabIndex = 44;
            label51.Text = "15700";
            // 
            // checkBox37
            // 
            checkBox37.AutoSize = true;
            checkBox37.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox37.Location = new System.Drawing.Point(363, 527);
            checkBox37.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox37.Name = "checkBox37";
            checkBox37.Size = new System.Drawing.Size(96, 23);
            checkBox37.TabIndex = 42;
            checkBox37.Text = "하지 않는 삶";
            checkBox37.UseVisualStyleBackColor = true;
            // 
            // checkBox38
            // 
            checkBox38.AutoSize = true;
            checkBox38.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox38.Location = new System.Drawing.Point(363, 342);
            checkBox38.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox38.Name = "checkBox38";
            checkBox38.Size = new System.Drawing.Size(116, 23);
            checkBox38.TabIndex = 41;
            checkBox38.Text = "어푸어푸 라이프";
            checkBox38.UseVisualStyleBackColor = true;
            // 
            // checkBox39
            // 
            checkBox39.AutoSize = true;
            checkBox39.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox39.Location = new System.Drawing.Point(27, 527);
            checkBox39.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox39.Name = "checkBox39";
            checkBox39.Size = new System.Drawing.Size(100, 23);
            checkBox39.TabIndex = 40;
            checkBox39.Text = "소년, 잘 지내";
            checkBox39.UseVisualStyleBackColor = true;
            // 
            // checkBox40
            // 
            checkBox40.AutoSize = true;
            checkBox40.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox40.Location = new System.Drawing.Point(198, 527);
            checkBox40.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox40.Name = "checkBox40";
            checkBox40.Size = new System.Drawing.Size(144, 23);
            checkBox40.TabIndex = 39;
            checkBox40.Text = "귀찮지만 매일 씁니다";
            checkBox40.UseVisualStyleBackColor = true;
            // 
            // checkBox41
            // 
            checkBox41.AutoSize = true;
            checkBox41.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox41.Location = new System.Drawing.Point(198, 342);
            checkBox41.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox41.Name = "checkBox41";
            checkBox41.Size = new System.Drawing.Size(84, 23);
            checkBox41.TabIndex = 38;
            checkBox41.Text = "결혼, 여름";
            checkBox41.UseVisualStyleBackColor = true;
            // 
            // checkBox42
            // 
            checkBox42.AutoSize = true;
            checkBox42.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox42.Location = new System.Drawing.Point(27, 342);
            checkBox42.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox42.Name = "checkBox42";
            checkBox42.Size = new System.Drawing.Size(132, 23);
            checkBox42.TabIndex = 37;
            checkBox42.Text = "우리는 가끔 아름...";
            checkBox42.UseVisualStyleBackColor = true;
            // 
            // checkBox43
            // 
            checkBox43.AutoSize = true;
            checkBox43.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox43.Location = new System.Drawing.Point(363, 170);
            checkBox43.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox43.Name = "checkBox43";
            checkBox43.Size = new System.Drawing.Size(144, 23);
            checkBox43.TabIndex = 36;
            checkBox43.Text = "내 인생에 무임술차...";
            checkBox43.UseVisualStyleBackColor = true;
            // 
            // checkBox44
            // 
            checkBox44.AutoSize = true;
            checkBox44.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox44.Location = new System.Drawing.Point(198, 170);
            checkBox44.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox44.Name = "checkBox44";
            checkBox44.Size = new System.Drawing.Size(148, 23);
            checkBox44.TabIndex = 43;
            checkBox44.Text = "늘 너의 편이 되어줄게";
            checkBox44.UseVisualStyleBackColor = true;
            // 
            // checkBox45
            // 
            checkBox45.AutoSize = true;
            checkBox45.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox45.Location = new System.Drawing.Point(27, 170);
            checkBox45.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox45.Name = "checkBox45";
            checkBox45.Size = new System.Drawing.Size(136, 23);
            checkBox45.TabIndex = 35;
            checkBox45.Text = "나는 너랑 노는 게...";
            checkBox45.UseVisualStyleBackColor = true;
            // 
            // tabPageDevelope
            // 
            tabPageDevelope.BackColor = System.Drawing.Color.PowderBlue;
            tabPageDevelope.Controls.Add(pictureBox46);
            tabPageDevelope.Controls.Add(pictureBox47);
            tabPageDevelope.Controls.Add(pictureBox48);
            tabPageDevelope.Controls.Add(pictureBox49);
            tabPageDevelope.Controls.Add(pictureBox50);
            tabPageDevelope.Controls.Add(pictureBox51);
            tabPageDevelope.Controls.Add(pictureBox52);
            tabPageDevelope.Controls.Add(pictureBox53);
            tabPageDevelope.Controls.Add(pictureBox54);
            tabPageDevelope.Controls.Add(label53);
            tabPageDevelope.Controls.Add(label54);
            tabPageDevelope.Controls.Add(label55);
            tabPageDevelope.Controls.Add(label56);
            tabPageDevelope.Controls.Add(label57);
            tabPageDevelope.Controls.Add(label58);
            tabPageDevelope.Controls.Add(label59);
            tabPageDevelope.Controls.Add(label60);
            tabPageDevelope.Controls.Add(label61);
            tabPageDevelope.Controls.Add(checkBox46);
            tabPageDevelope.Controls.Add(checkBox47);
            tabPageDevelope.Controls.Add(checkBox48);
            tabPageDevelope.Controls.Add(checkBox49);
            tabPageDevelope.Controls.Add(checkBox50);
            tabPageDevelope.Controls.Add(checkBox51);
            tabPageDevelope.Controls.Add(checkBox52);
            tabPageDevelope.Controls.Add(checkBox53);
            tabPageDevelope.Controls.Add(checkBox54);
            tabPageDevelope.Location = new System.Drawing.Point(4, 24);
            tabPageDevelope.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPageDevelope.Name = "tabPageDevelope";
            tabPageDevelope.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPageDevelope.Size = new System.Drawing.Size(714, 603);
            tabPageDevelope.TabIndex = 2;
            tabPageDevelope.Text = "자기계발";
            // 
            // pictureBox46
            // 
            pictureBox46.Image = Properties.Resources.쇼타임;
            pictureBox46.Location = new System.Drawing.Point(388, 399);
            pictureBox46.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox46.Name = "pictureBox46";
            pictureBox46.Size = new System.Drawing.Size(110, 122);
            pictureBox46.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox46.TabIndex = 92;
            pictureBox46.TabStop = false;
            // 
            // pictureBox47
            // 
            pictureBox47.Image = Properties.Resources.컨티;
            pictureBox47.Location = new System.Drawing.Point(388, 214);
            pictureBox47.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox47.Name = "pictureBox47";
            pictureBox47.Size = new System.Drawing.Size(110, 122);
            pictureBox47.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox47.TabIndex = 91;
            pictureBox47.TabStop = false;
            // 
            // pictureBox48
            // 
            pictureBox48.Image = Properties.Resources.누구도;
            pictureBox48.Location = new System.Drawing.Point(388, 44);
            pictureBox48.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox48.Name = "pictureBox48";
            pictureBox48.Size = new System.Drawing.Size(110, 122);
            pictureBox48.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox48.TabIndex = 90;
            pictureBox48.TabStop = false;
            // 
            // pictureBox49
            // 
            pictureBox49.Image = Properties.Resources.삶해답;
            pictureBox49.Location = new System.Drawing.Point(207, 399);
            pictureBox49.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox49.Name = "pictureBox49";
            pictureBox49.Size = new System.Drawing.Size(110, 122);
            pictureBox49.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox49.TabIndex = 89;
            pictureBox49.TabStop = false;
            // 
            // pictureBox50
            // 
            pictureBox50.Image = Properties.Resources.부의_원리;
            pictureBox50.Location = new System.Drawing.Point(24, 399);
            pictureBox50.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox50.Name = "pictureBox50";
            pictureBox50.Size = new System.Drawing.Size(110, 122);
            pictureBox50.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox50.TabIndex = 88;
            pictureBox50.TabStop = false;
            // 
            // pictureBox51
            // 
            pictureBox51.Image = Properties.Resources.꽂히는;
            pictureBox51.Location = new System.Drawing.Point(207, 214);
            pictureBox51.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox51.Name = "pictureBox51";
            pictureBox51.Size = new System.Drawing.Size(110, 122);
            pictureBox51.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox51.TabIndex = 87;
            pictureBox51.TabStop = false;
            // 
            // pictureBox52
            // 
            pictureBox52.Image = Properties.Resources.다정한;
            pictureBox52.Location = new System.Drawing.Point(24, 214);
            pictureBox52.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox52.Name = "pictureBox52";
            pictureBox52.Size = new System.Drawing.Size(110, 122);
            pictureBox52.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox52.TabIndex = 86;
            pictureBox52.TabStop = false;
            // 
            // pictureBox53
            // 
            pictureBox53.Image = Properties.Resources.데일카네기;
            pictureBox53.Location = new System.Drawing.Point(207, 44);
            pictureBox53.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox53.Name = "pictureBox53";
            pictureBox53.Size = new System.Drawing.Size(110, 122);
            pictureBox53.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox53.TabIndex = 85;
            pictureBox53.TabStop = false;
            // 
            // pictureBox54
            // 
            pictureBox54.Image = Properties.Resources.힘든일;
            pictureBox54.Location = new System.Drawing.Point(24, 44);
            pictureBox54.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox54.Name = "pictureBox54";
            pictureBox54.Size = new System.Drawing.Size(110, 122);
            pictureBox54.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox54.TabIndex = 84;
            pictureBox54.TabStop = false;
            // 
            // label53
            // 
            label53.AutoSize = true;
            label53.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label53.Location = new System.Drawing.Point(382, 543);
            label53.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label53.Name = "label53";
            label53.Size = new System.Drawing.Size(49, 19);
            label53.TabIndex = 80;
            label53.Text = "15700";
            // 
            // label54
            // 
            label54.AutoSize = true;
            label54.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label54.Location = new System.Drawing.Point(216, 543);
            label54.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label54.Name = "label54";
            label54.Size = new System.Drawing.Size(49, 19);
            label54.TabIndex = 79;
            label54.Text = "16000";
            // 
            // label55
            // 
            label55.AutoSize = true;
            label55.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label55.Location = new System.Drawing.Point(382, 359);
            label55.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label55.Name = "label55";
            label55.Size = new System.Drawing.Size(49, 19);
            label55.TabIndex = 81;
            label55.Text = "16200";
            // 
            // label56
            // 
            label56.AutoSize = true;
            label56.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label56.Location = new System.Drawing.Point(216, 359);
            label56.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label56.Name = "label56";
            label56.Size = new System.Drawing.Size(49, 19);
            label56.TabIndex = 78;
            label56.Text = "16900";
            // 
            // label57
            // 
            label57.AutoSize = true;
            label57.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label57.Location = new System.Drawing.Point(43, 543);
            label57.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label57.Name = "label57";
            label57.Size = new System.Drawing.Size(49, 19);
            label57.TabIndex = 77;
            label57.Text = "16900";
            // 
            // label58
            // 
            label58.AutoSize = true;
            label58.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label58.Location = new System.Drawing.Point(382, 188);
            label58.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label58.Name = "label58";
            label58.Size = new System.Drawing.Size(49, 19);
            label58.TabIndex = 76;
            label58.Text = "17100";
            // 
            // label59
            // 
            label59.AutoSize = true;
            label59.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label59.Location = new System.Drawing.Point(43, 359);
            label59.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label59.Name = "label59";
            label59.Size = new System.Drawing.Size(49, 19);
            label59.TabIndex = 75;
            label59.Text = "15900";
            // 
            // label60
            // 
            label60.AutoSize = true;
            label60.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label60.Location = new System.Drawing.Point(216, 188);
            label60.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label60.Name = "label60";
            label60.Size = new System.Drawing.Size(49, 19);
            label60.TabIndex = 74;
            label60.Text = "18000";
            // 
            // label61
            // 
            label61.AutoSize = true;
            label61.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label61.Location = new System.Drawing.Point(44, 188);
            label61.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label61.Name = "label61";
            label61.Size = new System.Drawing.Size(49, 19);
            label61.TabIndex = 73;
            label61.Text = "16200";
            // 
            // checkBox46
            // 
            checkBox46.AutoSize = true;
            checkBox46.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox46.Location = new System.Drawing.Point(363, 527);
            checkBox46.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox46.Name = "checkBox46";
            checkBox46.Size = new System.Drawing.Size(144, 23);
            checkBox46.TabIndex = 71;
            checkBox46.Text = "오타니 쇼헤이의 쇼...";
            checkBox46.UseVisualStyleBackColor = true;
            // 
            // checkBox47
            // 
            checkBox47.AutoSize = true;
            checkBox47.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox47.Location = new System.Drawing.Point(363, 342);
            checkBox47.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox47.Name = "checkBox47";
            checkBox47.Size = new System.Drawing.Size(88, 23);
            checkBox47.TabIndex = 70;
            checkBox47.Text = "컨티뉴어스";
            checkBox47.UseVisualStyleBackColor = true;
            // 
            // checkBox48
            // 
            checkBox48.AutoSize = true;
            checkBox48.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox48.Location = new System.Drawing.Point(27, 527);
            checkBox48.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox48.Name = "checkBox48";
            checkBox48.Size = new System.Drawing.Size(136, 23);
            checkBox48.TabIndex = 69;
            checkBox48.Text = "밥 프록터 부의 원리";
            checkBox48.UseVisualStyleBackColor = true;
            // 
            // checkBox49
            // 
            checkBox49.AutoSize = true;
            checkBox49.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox49.Location = new System.Drawing.Point(198, 527);
            checkBox49.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox49.Name = "checkBox49";
            checkBox49.Size = new System.Drawing.Size(132, 23);
            checkBox49.TabIndex = 68;
            checkBox49.Text = "나는 어떻게 삶의...";
            checkBox49.UseVisualStyleBackColor = true;
            // 
            // checkBox50
            // 
            checkBox50.AutoSize = true;
            checkBox50.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox50.Location = new System.Drawing.Point(198, 342);
            checkBox50.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox50.Name = "checkBox50";
            checkBox50.Size = new System.Drawing.Size(104, 23);
            checkBox50.TabIndex = 67;
            checkBox50.Text = "꽂히는 글쓰기";
            checkBox50.UseVisualStyleBackColor = true;
            // 
            // checkBox51
            // 
            checkBox51.AutoSize = true;
            checkBox51.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox51.Location = new System.Drawing.Point(27, 342);
            checkBox51.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox51.Name = "checkBox51";
            checkBox51.Size = new System.Drawing.Size(156, 23);
            checkBox51.TabIndex = 66;
            checkBox51.Text = "다정한 말이 똑똑함을...";
            checkBox51.UseVisualStyleBackColor = true;
            // 
            // checkBox52
            // 
            checkBox52.AutoSize = true;
            checkBox52.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox52.Location = new System.Drawing.Point(363, 170);
            checkBox52.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox52.Name = "checkBox52";
            checkBox52.Size = new System.Drawing.Size(144, 23);
            checkBox52.TabIndex = 65;
            checkBox52.Text = "누구도 나를 파괴할...";
            checkBox52.UseVisualStyleBackColor = true;
            // 
            // checkBox53
            // 
            checkBox53.AutoSize = true;
            checkBox53.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox53.Location = new System.Drawing.Point(198, 170);
            checkBox53.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox53.Name = "checkBox53";
            checkBox53.Size = new System.Drawing.Size(156, 23);
            checkBox53.TabIndex = 72;
            checkBox53.Text = "데일 카네기 인간관계론";
            checkBox53.UseVisualStyleBackColor = true;
            // 
            // checkBox54
            // 
            checkBox54.AutoSize = true;
            checkBox54.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox54.Location = new System.Drawing.Point(27, 170);
            checkBox54.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox54.Name = "checkBox54";
            checkBox54.Size = new System.Drawing.Size(136, 23);
            checkBox54.TabIndex = 64;
            checkBox54.Text = "힘든 일을 먼저 하라";
            checkBox54.UseVisualStyleBackColor = true;
            // 
            // tabPageNew
            // 
            tabPageNew.Controls.Add(tabControl4);
            tabPageNew.Location = new System.Drawing.Point(4, 32);
            tabPageNew.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPageNew.Name = "tabPageNew";
            tabPageNew.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPageNew.Size = new System.Drawing.Size(528, 636);
            tabPageNew.TabIndex = 2;
            tabPageNew.Text = "신상품";
            tabPageNew.UseVisualStyleBackColor = true;
            // 
            // tabControl4
            // 
            tabControl4.Controls.Add(tabPage1);
            tabControl4.Controls.Add(tabPage2);
            tabControl4.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            tabControl4.Location = new System.Drawing.Point(0, 4);
            tabControl4.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabControl4.Name = "tabControl4";
            tabControl4.SelectedIndex = 0;
            tabControl4.Size = new System.Drawing.Size(531, 638);
            tabControl4.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = System.Drawing.Color.PowderBlue;
            tabPage1.Controls.Add(pictureBox55);
            tabPage1.Controls.Add(pictureBox56);
            tabPage1.Controls.Add(pictureBox57);
            tabPage1.Controls.Add(pictureBox58);
            tabPage1.Controls.Add(pictureBox59);
            tabPage1.Controls.Add(pictureBox60);
            tabPage1.Controls.Add(pictureBox61);
            tabPage1.Controls.Add(pictureBox62);
            tabPage1.Controls.Add(pictureBox63);
            tabPage1.Controls.Add(label42);
            tabPage1.Controls.Add(label52);
            tabPage1.Controls.Add(label62);
            tabPage1.Controls.Add(label63);
            tabPage1.Controls.Add(label64);
            tabPage1.Controls.Add(label65);
            tabPage1.Controls.Add(label66);
            tabPage1.Controls.Add(label67);
            tabPage1.Controls.Add(label68);
            tabPage1.Controls.Add(checkBox55);
            tabPage1.Controls.Add(checkBox56);
            tabPage1.Controls.Add(checkBox57);
            tabPage1.Controls.Add(checkBox58);
            tabPage1.Controls.Add(checkBox59);
            tabPage1.Controls.Add(checkBox60);
            tabPage1.Controls.Add(checkBox61);
            tabPage1.Controls.Add(checkBox62);
            tabPage1.Controls.Add(checkBox63);
            tabPage1.Controls.Add(label32);
            tabPage1.Location = new System.Drawing.Point(4, 32);
            tabPage1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPage1.Size = new System.Drawing.Size(523, 602);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "국내도서";
            // 
            // pictureBox55
            // 
            pictureBox55.Image = Properties.Resources.호랭면;
            pictureBox55.Location = new System.Drawing.Point(205, 212);
            pictureBox55.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox55.Name = "pictureBox55";
            pictureBox55.Size = new System.Drawing.Size(110, 122);
            pictureBox55.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox55.TabIndex = 94;
            pictureBox55.TabStop = false;
            // 
            // pictureBox56
            // 
            pictureBox56.Image = Properties.Resources.노인;
            pictureBox56.Location = new System.Drawing.Point(203, 397);
            pictureBox56.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox56.Name = "pictureBox56";
            pictureBox56.Size = new System.Drawing.Size(110, 122);
            pictureBox56.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox56.TabIndex = 93;
            pictureBox56.TabStop = false;
            // 
            // pictureBox57
            // 
            pictureBox57.Image = Properties.Resources.맑은_날;
            pictureBox57.Location = new System.Drawing.Point(20, 397);
            pictureBox57.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox57.Name = "pictureBox57";
            pictureBox57.Size = new System.Drawing.Size(110, 122);
            pictureBox57.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox57.TabIndex = 92;
            pictureBox57.TabStop = false;
            // 
            // pictureBox58
            // 
            pictureBox58.Image = Properties.Resources.복숭아;
            pictureBox58.Location = new System.Drawing.Point(20, 212);
            pictureBox58.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox58.Name = "pictureBox58";
            pictureBox58.Size = new System.Drawing.Size(110, 122);
            pictureBox58.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox58.TabIndex = 91;
            pictureBox58.TabStop = false;
            // 
            // pictureBox59
            // 
            pictureBox59.Image = Properties.Resources.건널목;
            pictureBox59.Location = new System.Drawing.Point(203, 42);
            pictureBox59.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox59.Name = "pictureBox59";
            pictureBox59.Size = new System.Drawing.Size(110, 122);
            pictureBox59.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox59.TabIndex = 87;
            pictureBox59.TabStop = false;
            // 
            // pictureBox60
            // 
            pictureBox60.Image = Properties.Resources.미래;
            pictureBox60.Location = new System.Drawing.Point(371, 397);
            pictureBox60.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox60.Name = "pictureBox60";
            pictureBox60.Size = new System.Drawing.Size(110, 122);
            pictureBox60.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox60.TabIndex = 90;
            pictureBox60.TabStop = false;
            // 
            // pictureBox61
            // 
            pictureBox61.Image = Properties.Resources.내친구;
            pictureBox61.Location = new System.Drawing.Point(371, 212);
            pictureBox61.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox61.Name = "pictureBox61";
            pictureBox61.Size = new System.Drawing.Size(110, 122);
            pictureBox61.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox61.TabIndex = 89;
            pictureBox61.TabStop = false;
            // 
            // pictureBox62
            // 
            pictureBox62.Image = Properties.Resources.심플;
            pictureBox62.Location = new System.Drawing.Point(371, 42);
            pictureBox62.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox62.Name = "pictureBox62";
            pictureBox62.Size = new System.Drawing.Size(110, 122);
            pictureBox62.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox62.TabIndex = 88;
            pictureBox62.TabStop = false;
            // 
            // pictureBox63
            // 
            pictureBox63.Image = Properties.Resources.서울대;
            pictureBox63.Location = new System.Drawing.Point(20, 42);
            pictureBox63.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox63.Name = "pictureBox63";
            pictureBox63.Size = new System.Drawing.Size(110, 122);
            pictureBox63.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox63.TabIndex = 86;
            pictureBox63.TabStop = false;
            // 
            // label42
            // 
            label42.AutoSize = true;
            label42.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label42.Location = new System.Drawing.Point(374, 544);
            label42.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label42.Name = "label42";
            label42.Size = new System.Drawing.Size(49, 19);
            label42.TabIndex = 85;
            label42.Text = "15120";
            // 
            // label52
            // 
            label52.AutoSize = true;
            label52.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label52.Location = new System.Drawing.Point(208, 544);
            label52.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label52.Name = "label52";
            label52.Size = new System.Drawing.Size(49, 19);
            label52.TabIndex = 84;
            label52.Text = "15120";
            // 
            // label62
            // 
            label62.AutoSize = true;
            label62.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label62.Location = new System.Drawing.Point(374, 360);
            label62.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label62.Name = "label62";
            label62.Size = new System.Drawing.Size(49, 19);
            label62.TabIndex = 83;
            label62.Text = "11700";
            // 
            // label63
            // 
            label63.AutoSize = true;
            label63.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label63.Location = new System.Drawing.Point(208, 360);
            label63.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label63.Name = "label63";
            label63.Size = new System.Drawing.Size(49, 19);
            label63.TabIndex = 82;
            label63.Text = "14220";
            // 
            // label64
            // 
            label64.AutoSize = true;
            label64.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label64.Location = new System.Drawing.Point(35, 544);
            label64.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label64.Name = "label64";
            label64.Size = new System.Drawing.Size(49, 19);
            label64.TabIndex = 81;
            label64.Text = "15300";
            // 
            // label65
            // 
            label65.AutoSize = true;
            label65.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label65.Location = new System.Drawing.Point(376, 186);
            label65.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label65.Name = "label65";
            label65.Size = new System.Drawing.Size(49, 19);
            label65.TabIndex = 80;
            label65.Text = "17100";
            // 
            // label66
            // 
            label66.AutoSize = true;
            label66.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label66.Location = new System.Drawing.Point(35, 360);
            label66.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label66.Name = "label66";
            label66.Size = new System.Drawing.Size(49, 19);
            label66.TabIndex = 79;
            label66.Text = "14220";
            // 
            // label67
            // 
            label67.AutoSize = true;
            label67.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label67.Location = new System.Drawing.Point(210, 186);
            label67.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label67.Name = "label67";
            label67.Size = new System.Drawing.Size(49, 19);
            label67.TabIndex = 78;
            label67.Text = "15300";
            // 
            // label68
            // 
            label68.AutoSize = true;
            label68.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label68.Location = new System.Drawing.Point(38, 186);
            label68.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label68.Name = "label68";
            label68.Size = new System.Drawing.Size(49, 19);
            label68.TabIndex = 77;
            label68.Text = "16200";
            // 
            // checkBox55
            // 
            checkBox55.AutoSize = true;
            checkBox55.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox55.Location = new System.Drawing.Point(357, 527);
            checkBox55.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox55.Name = "checkBox55";
            checkBox55.Size = new System.Drawing.Size(152, 23);
            checkBox55.TabIndex = 75;
            checkBox55.Text = "우리가 살 수 없는 미래";
            checkBox55.UseVisualStyleBackColor = true;
            // 
            // checkBox56
            // 
            checkBox56.AutoSize = true;
            checkBox56.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox56.Location = new System.Drawing.Point(357, 342);
            checkBox56.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox56.Name = "checkBox56";
            checkBox56.Size = new System.Drawing.Size(108, 23);
            checkBox56.TabIndex = 74;
            checkBox56.Text = "내친구, 아병호";
            checkBox56.UseVisualStyleBackColor = true;
            // 
            // checkBox57
            // 
            checkBox57.AutoSize = true;
            checkBox57.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox57.Location = new System.Drawing.Point(21, 527);
            checkBox57.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox57.Name = "checkBox57";
            checkBox57.Size = new System.Drawing.Size(144, 23);
            checkBox57.TabIndex = 73;
            checkBox57.Text = "맑은 날이 아니어서...";
            checkBox57.UseVisualStyleBackColor = true;
            // 
            // checkBox58
            // 
            checkBox58.AutoSize = true;
            checkBox58.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox58.Location = new System.Drawing.Point(190, 527);
            checkBox58.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox58.Name = "checkBox58";
            checkBox58.Size = new System.Drawing.Size(116, 23);
            checkBox58.TabIndex = 72;
            checkBox58.Text = "초보 노인입니다";
            checkBox58.UseVisualStyleBackColor = true;
            // 
            // checkBox59
            // 
            checkBox59.AutoSize = true;
            checkBox59.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox59.Location = new System.Drawing.Point(190, 342);
            checkBox59.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox59.Name = "checkBox59";
            checkBox59.Size = new System.Drawing.Size(64, 23);
            checkBox59.TabIndex = 71;
            checkBox59.Text = "호랭면";
            checkBox59.UseVisualStyleBackColor = true;
            // 
            // checkBox60
            // 
            checkBox60.AutoSize = true;
            checkBox60.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox60.Location = new System.Drawing.Point(21, 342);
            checkBox60.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox60.Name = "checkBox60";
            checkBox60.Size = new System.Drawing.Size(144, 23);
            checkBox60.TabIndex = 70;
            checkBox60.Text = "복숭아 디저트 레시피";
            checkBox60.UseVisualStyleBackColor = true;
            // 
            // checkBox61
            // 
            checkBox61.AutoSize = true;
            checkBox61.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox61.Location = new System.Drawing.Point(357, 170);
            checkBox61.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox61.Name = "checkBox61";
            checkBox61.Size = new System.Drawing.Size(100, 23);
            checkBox61.TabIndex = 69;
            checkBox61.Text = "심플피트니스";
            checkBox61.UseVisualStyleBackColor = true;
            // 
            // checkBox62
            // 
            checkBox62.AutoSize = true;
            checkBox62.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox62.Location = new System.Drawing.Point(190, 170);
            checkBox62.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox62.Name = "checkBox62";
            checkBox62.Size = new System.Drawing.Size(104, 23);
            checkBox62.TabIndex = 76;
            checkBox62.Text = "건널목의 유령";
            checkBox62.UseVisualStyleBackColor = true;
            // 
            // checkBox63
            // 
            checkBox63.AutoSize = true;
            checkBox63.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox63.Location = new System.Drawing.Point(21, 170);
            checkBox63.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox63.Name = "checkBox63";
            checkBox63.Size = new System.Drawing.Size(164, 23);
            checkBox63.TabIndex = 68;
            checkBox63.Text = "학원비 0원으로 서울대...";
            checkBox63.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Location = new System.Drawing.Point(18, 16);
            label32.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label32.Name = "label32";
            label32.Size = new System.Drawing.Size(118, 23);
            label32.TabIndex = 0;
            label32.Text = "MD추천 리스트";
            // 
            // tabPage2
            // 
            tabPage2.BackColor = System.Drawing.Color.PowderBlue;
            tabPage2.Controls.Add(pictureBox70);
            tabPage2.Controls.Add(pictureBox64);
            tabPage2.Controls.Add(pictureBox69);
            tabPage2.Controls.Add(pictureBox67);
            tabPage2.Controls.Add(pictureBox66);
            tabPage2.Controls.Add(pictureBox68);
            tabPage2.Controls.Add(pictureBox65);
            tabPage2.Controls.Add(pictureBox71);
            tabPage2.Controls.Add(label73);
            tabPage2.Controls.Add(pictureBox72);
            tabPage2.Controls.Add(label71);
            tabPage2.Controls.Add(label69);
            tabPage2.Controls.Add(label72);
            tabPage2.Controls.Add(label70);
            tabPage2.Controls.Add(label74);
            tabPage2.Controls.Add(label75);
            tabPage2.Controls.Add(label76);
            tabPage2.Controls.Add(checkBox67);
            tabPage2.Controls.Add(label77);
            tabPage2.Controls.Add(checkBox66);
            tabPage2.Controls.Add(checkBox68);
            tabPage2.Controls.Add(checkBox65);
            tabPage2.Controls.Add(checkBox64);
            tabPage2.Controls.Add(checkBox69);
            tabPage2.Controls.Add(checkBox70);
            tabPage2.Controls.Add(checkBox71);
            tabPage2.Controls.Add(checkBox72);
            tabPage2.Controls.Add(label78);
            tabPage2.Location = new System.Drawing.Point(4, 32);
            tabPage2.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            tabPage2.Size = new System.Drawing.Size(523, 602);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "외국도서";
            // 
            // pictureBox70
            // 
            pictureBox70.Image = Properties.Resources.우주를_듣;
            pictureBox70.Location = new System.Drawing.Point(206, 405);
            pictureBox70.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox70.Name = "pictureBox70";
            pictureBox70.Size = new System.Drawing.Size(110, 122);
            pictureBox70.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox70.TabIndex = 122;
            pictureBox70.TabStop = false;
            // 
            // pictureBox64
            // 
            pictureBox64.Image = Properties.Resources.Light;
            pictureBox64.Location = new System.Drawing.Point(206, 218);
            pictureBox64.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox64.Name = "pictureBox64";
            pictureBox64.Size = new System.Drawing.Size(110, 122);
            pictureBox64.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox64.TabIndex = 122;
            pictureBox64.TabStop = false;
            // 
            // pictureBox69
            // 
            pictureBox69.Image = Properties.Resources.내가예뻐진;
            pictureBox69.Location = new System.Drawing.Point(21, 405);
            pictureBox69.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox69.Name = "pictureBox69";
            pictureBox69.Size = new System.Drawing.Size(110, 122);
            pictureBox69.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox69.TabIndex = 119;
            pictureBox69.TabStop = false;
            // 
            // pictureBox67
            // 
            pictureBox67.Image = Properties.Resources.Raining;
            pictureBox67.Location = new System.Drawing.Point(21, 218);
            pictureBox67.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox67.Name = "pictureBox67";
            pictureBox67.Size = new System.Drawing.Size(110, 122);
            pictureBox67.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox67.TabIndex = 119;
            pictureBox67.TabStop = false;
            // 
            // pictureBox66
            // 
            pictureBox66.Image = Properties.Resources.앨리;
            pictureBox66.Location = new System.Drawing.Point(372, 405);
            pictureBox66.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox66.Name = "pictureBox66";
            pictureBox66.Size = new System.Drawing.Size(110, 122);
            pictureBox66.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox66.TabIndex = 116;
            pictureBox66.TabStop = false;
            // 
            // pictureBox68
            // 
            pictureBox68.Image = Properties.Resources.ege;
            pictureBox68.Location = new System.Drawing.Point(204, 48);
            pictureBox68.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox68.Name = "pictureBox68";
            pictureBox68.Size = new System.Drawing.Size(110, 122);
            pictureBox68.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox68.TabIndex = 115;
            pictureBox68.TabStop = false;
            // 
            // pictureBox65
            // 
            pictureBox65.Image = Properties.Resources.Alice;
            pictureBox65.Location = new System.Drawing.Point(372, 218);
            pictureBox65.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox65.Name = "pictureBox65";
            pictureBox65.Size = new System.Drawing.Size(110, 122);
            pictureBox65.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox65.TabIndex = 116;
            pictureBox65.TabStop = false;
            // 
            // pictureBox71
            // 
            pictureBox71.Image = Properties.Resources.Adrift;
            pictureBox71.Location = new System.Drawing.Point(372, 48);
            pictureBox71.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox71.Name = "pictureBox71";
            pictureBox71.Size = new System.Drawing.Size(110, 122);
            pictureBox71.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox71.TabIndex = 116;
            pictureBox71.TabStop = false;
            // 
            // label73
            // 
            label73.AutoSize = true;
            label73.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label73.Location = new System.Drawing.Point(376, 548);
            label73.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label73.Name = "label73";
            label73.Size = new System.Drawing.Size(49, 19);
            label73.TabIndex = 108;
            label73.Text = "15000";
            // 
            // pictureBox72
            // 
            pictureBox72.Image = Properties.Resources.Midnight;
            pictureBox72.Location = new System.Drawing.Point(21, 48);
            pictureBox72.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox72.Name = "pictureBox72";
            pictureBox72.Size = new System.Drawing.Size(110, 122);
            pictureBox72.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox72.TabIndex = 114;
            pictureBox72.TabStop = false;
            // 
            // label71
            // 
            label71.AutoSize = true;
            label71.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label71.Location = new System.Drawing.Point(208, 546);
            label71.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label71.Name = "label71";
            label71.Size = new System.Drawing.Size(49, 19);
            label71.TabIndex = 110;
            label71.Text = "16900";
            // 
            // label69
            // 
            label69.AutoSize = true;
            label69.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label69.Location = new System.Drawing.Point(376, 362);
            label69.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label69.Name = "label69";
            label69.Size = new System.Drawing.Size(49, 19);
            label69.TabIndex = 108;
            label69.Text = "19400";
            // 
            // label72
            // 
            label72.AutoSize = true;
            label72.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label72.Location = new System.Drawing.Point(208, 360);
            label72.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label72.Name = "label72";
            label72.Size = new System.Drawing.Size(49, 19);
            label72.TabIndex = 110;
            label72.Text = "24900";
            // 
            // label70
            // 
            label70.AutoSize = true;
            label70.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label70.Location = new System.Drawing.Point(35, 546);
            label70.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label70.Name = "label70";
            label70.Size = new System.Drawing.Size(49, 19);
            label70.TabIndex = 107;
            label70.Text = "15000";
            // 
            // label74
            // 
            label74.AutoSize = true;
            label74.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label74.Location = new System.Drawing.Point(376, 187);
            label74.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label74.Name = "label74";
            label74.Size = new System.Drawing.Size(49, 19);
            label74.TabIndex = 108;
            label74.Text = "18200";
            // 
            // label75
            // 
            label75.AutoSize = true;
            label75.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label75.Location = new System.Drawing.Point(35, 360);
            label75.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label75.Name = "label75";
            label75.Size = new System.Drawing.Size(49, 19);
            label75.TabIndex = 107;
            label75.Text = "24600";
            // 
            // label76
            // 
            label76.AutoSize = true;
            label76.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label76.Location = new System.Drawing.Point(210, 187);
            label76.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label76.Name = "label76";
            label76.Size = new System.Drawing.Size(49, 19);
            label76.TabIndex = 106;
            label76.Text = "21000";
            // 
            // checkBox67
            // 
            checkBox67.AutoSize = true;
            checkBox67.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox67.Location = new System.Drawing.Point(190, 529);
            checkBox67.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox67.Name = "checkBox67";
            checkBox67.Size = new System.Drawing.Size(120, 23);
            checkBox67.TabIndex = 99;
            checkBox67.Text = "우주를 듣는 소년";
            checkBox67.UseVisualStyleBackColor = true;
            // 
            // label77
            // 
            label77.AutoSize = true;
            label77.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label77.Location = new System.Drawing.Point(38, 187);
            label77.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label77.Name = "label77";
            label77.Size = new System.Drawing.Size(49, 19);
            label77.TabIndex = 105;
            label77.Text = "13000";
            // 
            // checkBox66
            // 
            checkBox66.AutoSize = true;
            checkBox66.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox66.Location = new System.Drawing.Point(357, 529);
            checkBox66.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox66.Name = "checkBox66";
            checkBox66.Size = new System.Drawing.Size(76, 23);
            checkBox66.TabIndex = 97;
            checkBox66.Text = "앨리아스";
            checkBox66.UseVisualStyleBackColor = true;
            // 
            // checkBox68
            // 
            checkBox68.AutoSize = true;
            checkBox68.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox68.Location = new System.Drawing.Point(190, 342);
            checkBox68.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox68.Name = "checkBox68";
            checkBox68.Size = new System.Drawing.Size(157, 23);
            checkBox68.TabIndex = 99;
            checkBox68.Text = "The Light We Carry";
            checkBox68.UseVisualStyleBackColor = true;
            // 
            // checkBox65
            // 
            checkBox65.AutoSize = true;
            checkBox65.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox65.Location = new System.Drawing.Point(21, 529);
            checkBox65.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox65.Name = "checkBox65";
            checkBox65.Size = new System.Drawing.Size(144, 23);
            checkBox65.TabIndex = 98;
            checkBox65.Text = "내가 예뻐진 그 여름1";
            checkBox65.UseVisualStyleBackColor = true;
            // 
            // checkBox64
            // 
            checkBox64.AutoSize = true;
            checkBox64.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox64.Location = new System.Drawing.Point(357, 342);
            checkBox64.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox64.Name = "checkBox64";
            checkBox64.Size = new System.Drawing.Size(167, 23);
            checkBox64.TabIndex = 97;
            checkBox64.Text = "Alice in Wonderland";
            checkBox64.UseVisualStyleBackColor = true;
            // 
            // checkBox69
            // 
            checkBox69.AutoSize = true;
            checkBox69.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox69.Location = new System.Drawing.Point(21, 342);
            checkBox69.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox69.Name = "checkBox69";
            checkBox69.Size = new System.Drawing.Size(190, 23);
            checkBox69.TabIndex = 98;
            checkBox69.Text = "If it's Raining in Brazil,...";
            checkBox69.UseVisualStyleBackColor = true;
            // 
            // checkBox70
            // 
            checkBox70.AutoSize = true;
            checkBox70.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox70.Location = new System.Drawing.Point(357, 170);
            checkBox70.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox70.Name = "checkBox70";
            checkBox70.Size = new System.Drawing.Size(67, 23);
            checkBox70.TabIndex = 97;
            checkBox70.Text = "Adrift";
            checkBox70.UseVisualStyleBackColor = true;
            // 
            // checkBox71
            // 
            checkBox71.AutoSize = true;
            checkBox71.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox71.Location = new System.Drawing.Point(190, 170);
            checkBox71.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox71.Name = "checkBox71";
            checkBox71.Size = new System.Drawing.Size(61, 23);
            checkBox71.TabIndex = 104;
            checkBox71.Text = "Edge";
            checkBox71.UseVisualStyleBackColor = true;
            // 
            // checkBox72
            // 
            checkBox72.AutoSize = true;
            checkBox72.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            checkBox72.Location = new System.Drawing.Point(21, 170);
            checkBox72.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            checkBox72.Name = "checkBox72";
            checkBox72.Size = new System.Drawing.Size(172, 23);
            checkBox72.TabIndex = 96;
            checkBox72.Text = "The Midnight Library";
            checkBox72.UseVisualStyleBackColor = true;
            // 
            // label78
            // 
            label78.AutoSize = true;
            label78.Location = new System.Drawing.Point(18, 16);
            label78.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label78.Name = "label78";
            label78.Size = new System.Drawing.Size(118, 23);
            label78.TabIndex = 95;
            label78.Text = "MD추천 리스트";
            // 
            // listView1
            // 
            listView1.BackColor = System.Drawing.Color.FromArgb(192, 255, 192);
            listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] { bookName, bookPrice, bookMany });
            listView1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            listView1.ForeColor = System.Drawing.Color.Black;
            listView1.Location = new System.Drawing.Point(563, 181);
            listView1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            listView1.Name = "listView1";
            listView1.Size = new System.Drawing.Size(355, 551);
            listView1.TabIndex = 1;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = System.Windows.Forms.View.Details;
            // 
            // bookName
            // 
            bookName.Text = "도서명";
            bookName.Width = 100;
            // 
            // bookPrice
            // 
            bookPrice.Text = "가격";
            bookPrice.Width = 100;
            // 
            // bookMany
            // 
            bookMany.Text = "수량";
            bookMany.Width = 100;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label11.Location = new System.Drawing.Point(563, 740);
            label11.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(93, 23);
            label11.TabIndex = 2;
            label11.Text = "총 결제 금액";
            // 
            // textBox_price
            // 
            textBox_price.Location = new System.Drawing.Point(654, 737);
            textBox_price.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            textBox_price.Name = "textBox_price";
            textBox_price.Size = new System.Drawing.Size(264, 26);
            textBox_price.TabIndex = 3;
            // 
            // btn_Initial
            // 
            btn_Initial.BackColor = System.Drawing.Color.CornflowerBlue;
            btn_Initial.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
            btn_Initial.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_Initial.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Initial.ForeColor = System.Drawing.Color.White;
            btn_Initial.Location = new System.Drawing.Point(816, 682);
            btn_Initial.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            btn_Initial.Name = "btn_Initial";
            btn_Initial.Size = new System.Drawing.Size(86, 35);
            btn_Initial.TabIndex = 6;
            btn_Initial.Text = "모두 삭제";
            btn_Initial.UseVisualStyleBackColor = false;
            btn_Initial.Click += btn_Initial_Click;
            // 
            // button1
            // 
            button1.BackColor = System.Drawing.Color.CornflowerBlue;
            button1.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
            button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button1.ForeColor = System.Drawing.Color.White;
            button1.Location = new System.Drawing.Point(832, 771);
            button1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(86, 39);
            button1.TabIndex = 7;
            button1.Text = "결제하기";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // textBox2
            // 
            textBox2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            textBox2.BackColor = System.Drawing.Color.White;
            textBox2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            textBox2.Location = new System.Drawing.Point(343, 40);
            textBox2.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new System.Drawing.Size(437, 37);
            textBox2.TabIndex = 8;
            // 
            // button2
            // 
            button2.BackColor = System.Drawing.Color.Transparent;
            button2.Image = Properties.Resources.돋보기;
            button2.Location = new System.Drawing.Point(793, 36);
            button2.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            button2.Name = "button2";
            button2.Size = new System.Drawing.Size(41, 46);
            button2.TabIndex = 10;
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = System.Drawing.Color.White;
            button3.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button3.Location = new System.Drawing.Point(848, 212);
            button3.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            button3.Name = "button3";
            button3.Size = new System.Drawing.Size(27, 26);
            button3.TabIndex = 11;
            button3.Text = "-";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = System.Drawing.Color.White;
            button4.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button4.Location = new System.Drawing.Point(882, 212);
            button4.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            button4.Name = "button4";
            button4.Size = new System.Drawing.Size(27, 26);
            button4.TabIndex = 11;
            button4.Text = "+";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // pictureBox73
            // 
            pictureBox73.Image = Properties.Resources.교보문고_로고;
            pictureBox73.Location = new System.Drawing.Point(15, 2);
            pictureBox73.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox73.Name = "pictureBox73";
            pictureBox73.Size = new System.Drawing.Size(213, 96);
            pictureBox73.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox73.TabIndex = 12;
            pictureBox73.TabStop = false;
            // 
            // button5
            // 
            button5.BackColor = System.Drawing.Color.White;
            button5.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button5.Location = new System.Drawing.Point(848, 240);
            button5.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            button5.Name = "button5";
            button5.Size = new System.Drawing.Size(27, 26);
            button5.TabIndex = 11;
            button5.Text = "-";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.BackColor = System.Drawing.Color.White;
            button6.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button6.Location = new System.Drawing.Point(882, 240);
            button6.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            button6.Name = "button6";
            button6.Size = new System.Drawing.Size(27, 26);
            button6.TabIndex = 11;
            button6.Text = "+";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.BackColor = System.Drawing.Color.White;
            button7.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button7.Location = new System.Drawing.Point(848, 268);
            button7.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            button7.Name = "button7";
            button7.Size = new System.Drawing.Size(27, 26);
            button7.TabIndex = 11;
            button7.Text = "-";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.BackColor = System.Drawing.Color.White;
            button8.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button8.Location = new System.Drawing.Point(882, 268);
            button8.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            button8.Name = "button8";
            button8.Size = new System.Drawing.Size(27, 26);
            button8.TabIndex = 11;
            button8.Text = "+";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // pictureBox74
            // 
            pictureBox74.Image = Properties.Resources.검색;
            pictureBox74.Location = new System.Drawing.Point(230, 14);
            pictureBox74.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            pictureBox74.Name = "pictureBox74";
            pictureBox74.Size = new System.Drawing.Size(632, 84);
            pictureBox74.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox74.TabIndex = 13;
            pictureBox74.TabStop = false;
            // 
            // label79
            // 
            label79.AutoSize = true;
            label79.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label79.Location = new System.Drawing.Point(568, 142);
            label79.Name = "label79";
            label79.Size = new System.Drawing.Size(132, 29);
            label79.TabIndex = 14;
            label79.Text = "장바구니 목록";
            // 
            // pictureBox75
            // 
            pictureBox75.Image = Properties.Resources.장바구니;
            pictureBox75.Location = new System.Drawing.Point(694, 134);
            pictureBox75.Name = "pictureBox75";
            pictureBox75.Size = new System.Drawing.Size(41, 39);
            pictureBox75.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox75.TabIndex = 15;
            pictureBox75.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.White;
            ClientSize = new System.Drawing.Size(951, 814);
            Controls.Add(pictureBox75);
            Controls.Add(label79);
            Controls.Add(button2);
            Controls.Add(textBox2);
            Controls.Add(pictureBox74);
            Controls.Add(pictureBox73);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button1);
            Controls.Add(btn_Initial);
            Controls.Add(textBox_price);
            Controls.Add(label11);
            Controls.Add(listView1);
            Controls.Add(tabControl1);
            Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            Name = "Form1";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "Form1";
            tabControl1.ResumeLayout(false);
            tabPageBest.ResumeLayout(false);
            tabControl3.ResumeLayout(false);
            tabPageDay.ResumeLayout(false);
            tabPageDay.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            tabPageWeek.ResumeLayout(false);
            tabPageWeek.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            tabPageMonth.ResumeLayout(false);
            tabPageMonth.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox25).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox24).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox23).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox22).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox27).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox26).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox21).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).EndInit();
            tabPageCate.ResumeLayout(false);
            tabControl2.ResumeLayout(false);
            tabPageNovel.ResumeLayout(false);
            tabPageNovel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox28).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox29).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox30).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox31).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox32).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox33).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox34).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox35).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox36).EndInit();
            tabPagePoem.ResumeLayout(false);
            tabPagePoem.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox37).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox38).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox39).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox40).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox41).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox42).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox43).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox44).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox45).EndInit();
            tabPageDevelope.ResumeLayout(false);
            tabPageDevelope.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox46).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox47).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox48).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox49).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox50).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox51).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox52).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox53).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox54).EndInit();
            tabPageNew.ResumeLayout(false);
            tabControl4.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox55).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox56).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox57).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox58).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox59).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox60).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox61).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox62).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox63).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox70).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox64).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox69).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox67).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox66).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox68).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox65).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox71).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox72).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox73).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox74).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox75).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageBest;
        private System.Windows.Forms.TabPage tabPageCate;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPageNovel;
        private System.Windows.Forms.TabPage tabPagePoem;
        private System.Windows.Forms.TabPage tabPageDevelope;
        private System.Windows.Forms.TabPage tabPageNew;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPageDay;
        private System.Windows.Forms.TabPage tabPageWeek;
        private System.Windows.Forms.TabPage tabPageMonth;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ColumnHeader bookName;
        private System.Windows.Forms.ColumnHeader bookPrice;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.CheckBox checkBox22;
        private System.Windows.Forms.CheckBox checkBox23;
        private System.Windows.Forms.CheckBox checkBox24;
        private System.Windows.Forms.CheckBox checkBox25;
        private System.Windows.Forms.CheckBox checkBox26;
        private System.Windows.Forms.CheckBox checkBox27;
        private System.Windows.Forms.ColumnHeader bookMany;
        private System.Windows.Forms.Button btn_Initial;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.CheckBox checkBox28;
        private System.Windows.Forms.CheckBox checkBox29;
        private System.Windows.Forms.CheckBox checkBox30;
        private System.Windows.Forms.CheckBox checkBox31;
        private System.Windows.Forms.CheckBox checkBox32;
        private System.Windows.Forms.CheckBox checkBox33;
        private System.Windows.Forms.CheckBox checkBox34;
        private System.Windows.Forms.CheckBox checkBox35;
        private System.Windows.Forms.CheckBox checkBox36;
        private System.Windows.Forms.PictureBox pictureBox37;
        private System.Windows.Forms.PictureBox pictureBox38;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.PictureBox pictureBox40;
        private System.Windows.Forms.PictureBox pictureBox41;
        private System.Windows.Forms.PictureBox pictureBox42;
        private System.Windows.Forms.PictureBox pictureBox43;
        private System.Windows.Forms.PictureBox pictureBox44;
        private System.Windows.Forms.PictureBox pictureBox45;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.CheckBox checkBox37;
        private System.Windows.Forms.CheckBox checkBox38;
        private System.Windows.Forms.CheckBox checkBox39;
        private System.Windows.Forms.CheckBox checkBox40;
        private System.Windows.Forms.CheckBox checkBox41;
        private System.Windows.Forms.CheckBox checkBox42;
        private System.Windows.Forms.CheckBox checkBox43;
        private System.Windows.Forms.CheckBox checkBox44;
        private System.Windows.Forms.CheckBox checkBox45;
        private System.Windows.Forms.PictureBox pictureBox46;
        private System.Windows.Forms.PictureBox pictureBox47;
        private System.Windows.Forms.PictureBox pictureBox48;
        private System.Windows.Forms.PictureBox pictureBox49;
        private System.Windows.Forms.PictureBox pictureBox50;
        private System.Windows.Forms.PictureBox pictureBox51;
        private System.Windows.Forms.PictureBox pictureBox52;
        private System.Windows.Forms.PictureBox pictureBox53;
        private System.Windows.Forms.PictureBox pictureBox54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.CheckBox checkBox46;
        private System.Windows.Forms.CheckBox checkBox47;
        private System.Windows.Forms.CheckBox checkBox48;
        private System.Windows.Forms.CheckBox checkBox49;
        private System.Windows.Forms.CheckBox checkBox50;
        private System.Windows.Forms.CheckBox checkBox51;
        private System.Windows.Forms.CheckBox checkBox52;
        private System.Windows.Forms.CheckBox checkBox53;
        private System.Windows.Forms.CheckBox checkBox54;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.PictureBox pictureBox55;
        private System.Windows.Forms.PictureBox pictureBox56;
        private System.Windows.Forms.PictureBox pictureBox57;
        private System.Windows.Forms.PictureBox pictureBox58;
        private System.Windows.Forms.PictureBox pictureBox59;
        private System.Windows.Forms.PictureBox pictureBox60;
        private System.Windows.Forms.PictureBox pictureBox61;
        private System.Windows.Forms.PictureBox pictureBox62;
        private System.Windows.Forms.PictureBox pictureBox63;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.CheckBox checkBox55;
        private System.Windows.Forms.CheckBox checkBox56;
        private System.Windows.Forms.CheckBox checkBox57;
        private System.Windows.Forms.CheckBox checkBox58;
        private System.Windows.Forms.CheckBox checkBox59;
        private System.Windows.Forms.CheckBox checkBox60;
        private System.Windows.Forms.CheckBox checkBox61;
        private System.Windows.Forms.CheckBox checkBox62;
        private System.Windows.Forms.CheckBox checkBox63;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox pictureBox64;
        private System.Windows.Forms.PictureBox pictureBox67;
        private System.Windows.Forms.PictureBox pictureBox68;
        private System.Windows.Forms.PictureBox pictureBox71;
        private System.Windows.Forms.PictureBox pictureBox72;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.CheckBox checkBox68;
        private System.Windows.Forms.CheckBox checkBox69;
        private System.Windows.Forms.CheckBox checkBox70;
        private System.Windows.Forms.CheckBox checkBox71;
        private System.Windows.Forms.CheckBox checkBox72;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.PictureBox pictureBox70;
        private System.Windows.Forms.PictureBox pictureBox69;
        private System.Windows.Forms.PictureBox pictureBox66;
        private System.Windows.Forms.PictureBox pictureBox65;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.CheckBox checkBox67;
        private System.Windows.Forms.CheckBox checkBox66;
        private System.Windows.Forms.CheckBox checkBox65;
        private System.Windows.Forms.CheckBox checkBox64;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.PictureBox pictureBox73;
        public System.Windows.Forms.ListView listView1;
        public System.Windows.Forms.CheckBox checkBox1;
        public System.Windows.Forms.PictureBox pictureBox6;
        public System.Windows.Forms.CheckBox checkBox6;
        public System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.PictureBox pictureBox74;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.PictureBox pictureBox75;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TextBox textBox5;
        public System.Windows.Forms.TextBox textBox_price;
        public System.Windows.Forms.TextBox textBox2;
    }
}
