﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace 키오스크
{
    public partial class Form1 : Form
    {
        private void SetHiehgt(System.Windows.Forms.ListView LV, int height)
        {
            ImageList imageList = new ImageList();
            imageList.ImageSize = new Size(1, height);
            LV.SmallImageList = imageList;
        }


        public Form1()
        {
            InitializeComponent();
            listView1.View = View.Details;
            textBox1.Text = DateTime.Now.ToLongDateString();
            SetHiehgt(listView1, 30);

            textBox4.Text = DateTime.Now.ToString("yyyy년 MM월");
            textBox3.Text = DateTime.Now.ToLongDateString();
            textBox5.Text = DateTime.Now.AddDays(7).ToLongDateString();
        }


        int a, b, c, d, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v = 0;
        int price = 0;      //총가격

        int price1, price2, price3, price4, price5, price6, price7, price8, price9, price10, price11, price12, price13, price14, price15, price16, price17, price18, price19, price20 = 0;


        private void button29_Click(object sender, EventArgs e)         //수량 -
        {
            if (i > 1)
            {
                i--;
                //textBox5.Text = i.ToString();

                price -= int.Parse(label1.Text);
                textBox_price.Text = price.ToString();
                listView1.Items[0].SubItems[1].Text = price.ToString();
            }

            //textBox5.Text = 1.ToString();
        }

        private void button28_Click(object sender, EventArgs e)         //수량 +
        {

            i++;
            //textBox5.Text = i.ToString();

            price += int.Parse(label1.Text);
            textBox_price.Text = price.ToString();
            listView1.Items[0].SubItems[1].Text = price.ToString();
        }

        private void btn_Initial_Click(object sender, EventArgs e)          //모두 삭제
        {
            listView1.Items.Clear();

            textBox_price.Text = "";
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            checkBox4.Checked = false;
            checkBox5.Checked = false;
            checkBox6.Checked = false;
            checkBox7.Checked = false;
            checkBox8.Checked = false;
            checkBox9.Checked = false;
            price = 0;

        }

        //베스트-일간
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            a++;
            price1 += int.Parse(label1.Text);
            checkBox1.Checked = true;
            if (a == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox1.Text, label1.Text, a.ToString() }));
            }
            int count = listView1.Items.Count;
            if (a > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox1.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = a.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price1.ToString();
                    }
                }
            }

            price += int.Parse(label1.Text);
            textBox_price.Text = price.ToString();
        }       //최애

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            b++;
            price2 += int.Parse(label2.Text);
            checkBox2.Checked = true;
            if (b == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox2.Text, label2.Text, b.ToString() }));
            }
            int count = listView1.Items.Count;
            if (b > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox2.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = b.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price2.ToString();
                    }
                }
            }
            price += int.Parse(label2.Text);
            textBox_price.Text = price.ToString();
        }       //늘

        private void pictureBox3_Click(object sender, EventArgs e)      //세이노
        {
            c++;
            price3 += int.Parse(label3.Text);
            checkBox3.Checked = true;
            if (c == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox3.Text, label3.Text, c.ToString() }));
            }
            int count = listView1.Items.Count;
            if (c > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox3.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = c.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price3.ToString();
                    }
                }
            }
            price += int.Parse(label3.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox4_Click(object sender, EventArgs e)      //문과
        {
            d++;
            price4 += int.Parse(label4.Text);
            checkBox4.Checked = true;
            if (d == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox4.Text, label4.Text, d.ToString() }));
            }
            int count = listView1.Items.Count;
            if (d > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox4.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = d.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price4.ToString();
                    }
                }
            }
            price += int.Parse(label4.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox5_Click(object sender, EventArgs e)      //도쿄
        {
            f++;
            price5 += int.Parse(label5.Text);
            checkBox5.Checked = true;
            if (f == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox5.Text, label5.Text, f.ToString() }));
            }
            int count = listView1.Items.Count;
            if (f > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox5.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = f.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price5.ToString();
                    }
                }
            }
            price += int.Parse(label5.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox6_Click(object sender, EventArgs e)      //꿀벌
        {
            g++;
            price6 += int.Parse(label6.Text);
            checkBox6.Checked = true;
            if (g == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox6.Text, label6.Text, g.ToString() }));
            }
            int count = listView1.Items.Count;
            if (g > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox6.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = g.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price6.ToString();
                    }
                }
            }
            price += int.Parse(label6.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox7_Click(object sender, EventArgs e)      //역행자
        {
            h++;
            price7 += int.Parse(label7.Text);
            checkBox7.Checked = true;
            if (h == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox7.Text, label7.Text, h.ToString() }));
            }
            int count = listView1.Items.Count;
            if (h > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox7.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = h.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price7.ToString();
                    }
                }
            }
            price += int.Parse(label7.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox8_Click(object sender, EventArgs e)      //도둑
        {
            i++;
            price8 += int.Parse(label8.Text);
            checkBox9.Checked = true;
            if (i == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox9.Text, label8.Text, i.ToString() }));
            }
            int count = listView1.Items.Count;
            if (i > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox9.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = i.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price8.ToString();
                    }
                }
            }
            price += int.Parse(label8.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox9_Click(object sender, EventArgs e)      //아주희미한
        {
            j++;
            price9 += int.Parse(label9.Text);
            checkBox8.Checked = true;
            if (j == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox8.Text, label9.Text, j.ToString() }));
            }
            int count = listView1.Items.Count;
            if (j > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox8.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = j.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price9.ToString();
                    }
                }
            }
            price += int.Parse(label9.Text);
            textBox_price.Text = price.ToString();
        }

        private void button1_Click(object sender, EventArgs e)      //결제하기
        {
            Form2 modal = new Form2();
            modal.ShowDialog();
        }

        //베스트-주간
        private void pictureBox10_Click(object sender, EventArgs e)     //세이노
        {
            c++;
            price3 += int.Parse(label3.Text);
            checkBox18.Checked = true;

            int count = listView1.Items.Count;
            if (c > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox3.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = c.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price3.ToString();
                    }
                }
            }
            price += int.Parse(label3.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox12_Click(object sender, EventArgs e)     //문과
        {
            d++;
            price4 += int.Parse(label4.Text);
            checkBox17.Checked = true;

            int count = listView1.Items.Count;
            if (d > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox4.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = d.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price4.ToString();
                    }
                }
            }
            price += int.Parse(label4.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox11_Click(object sender, EventArgs e)     //역행자
        {
            h++;
            price7 += int.Parse(label7.Text);
            checkBox16.Checked = true;

            int count = listView1.Items.Count;
            if (h > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox7.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = h.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price7.ToString();
                    }
                }
            }
            price += int.Parse(label7.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox15_Click(object sender, EventArgs e)     //하늘
        {
            k++;
            price10 += int.Parse(label19.Text);
            checkBox15.Checked = true;
            if (k == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox15.Text, label19.Text, k.ToString() }));
            }
            int count = listView1.Items.Count;
            if (k > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox15.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = k.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price10.ToString();
                    }
                }
            }
            price += int.Parse(label19.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox13_Click(object sender, EventArgs e)     //도둑
        {
            i++;
            price8 += int.Parse(label8.Text);
            checkBox9.Checked = true;

            int count = listView1.Items.Count;
            if (i > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox9.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = i.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price8.ToString();
                    }
                }
            }
            price += int.Parse(label8.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox14_Click(object sender, EventArgs e)     //최애
        {
            a++;
            price1 += int.Parse(label1.Text);
            checkBox11.Checked = true;

            int count = listView1.Items.Count;
            if (a > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox1.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = a.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price1.ToString();
                    }
                }
            }
            price += int.Parse(label1.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox16_Click(object sender, EventArgs e)     //나는죽을때까지
        {
            l++;
            price11 += int.Parse(label17.Text);
            checkBox12.Checked = true;
            if (l == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox12.Text, label17.Text, l.ToString() }));
            }
            int count = listView1.Items.Count;
            if (l > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox12.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = l.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price11.ToString();
                    }
                }
            }
            price += int.Parse(label17.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox17_Click(object sender, EventArgs e)     //메리골드
        {
            m++;
            price12 += int.Parse(label14.Text);
            checkBox13.Checked = true;
            if (m == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox13.Text, label14.Text, m.ToString() }));
            }
            int count = listView1.Items.Count;
            if (m > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox13.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = m.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price12.ToString();
                    }
                }
            }
            price += int.Parse(label14.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox18_Click(object sender, EventArgs e)     //나는너랑노는게
        {
            n++;
            price13 += int.Parse(label13.Text);
            checkBox10.Checked = true;
            if (n == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox10.Text, label13.Text, n.ToString() }));
            }
            int count = listView1.Items.Count;
            if (n > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox10.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = n.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price13.ToString();
                    }
                }
            }
            price += int.Parse(label13.Text);
            textBox_price.Text = price.ToString();
        }

        //베스트-월간
        private void pictureBox19_Click(object sender, EventArgs e)     //세이노
        {
            c++;
            price3 += int.Parse(label3.Text);
            checkBox27.Checked = true;

            int count = listView1.Items.Count;
            if (c > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox3.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = c.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price3.ToString();
                    }
                }
            }
            price += int.Parse(label3.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox20_Click(object sender, EventArgs e)     //역행자
        {
            h++;
            price7 += int.Parse(label7.Text);
            checkBox26.Checked = true;

            int count = listView1.Items.Count;
            if (h > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox7.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = h.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price7.ToString();
                    }
                }
            }
            price += int.Parse(label7.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox21_Click(object sender, EventArgs e)     //문과
        {
            d++;
            price4 += int.Parse(label4.Text);
            checkBox25.Checked = true;

            int count = listView1.Items.Count;
            if (d > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox4.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = d.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price4.ToString();
                    }
                }
            }
            price += int.Parse(label4.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox22_Click(object sender, EventArgs e)     //도둑
        {
            i++;
            price8 += int.Parse(label8.Text);
            checkBox24.Checked = true;

            int count = listView1.Items.Count;
            if (i > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox9.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = i.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price8.ToString();
                    }
                }
            }
            price += int.Parse(label8.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox25_Click(object sender, EventArgs e)     //사장
        {
            o++;
            price14 += int.Parse(label26.Text);
            checkBox23.Checked = true;
            if (o == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox23.Text, label26.Text, o.ToString() }));
            }
            int count = listView1.Items.Count;
            if (o > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox23.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = o.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price14.ToString();
                    }
                }
            }
            price += int.Parse(label26.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox26_Click(object sender, EventArgs e)     //모든삶은
        {
            p++;
            price15 += int.Parse(label25.Text);
            checkBox20.Checked = true;
            if (p == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox20.Text, label25.Text, p.ToString() }));
            }
            int count = listView1.Items.Count;
            if (p > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox20.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = p.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price15.ToString();
                    }
                }
            }
            price += int.Parse(label25.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox23_Click(object sender, EventArgs e)     //메리골드
        {
            m++;
            price12 += int.Parse(label14.Text);
            checkBox21.Checked = true;

            int count = listView1.Items.Count;
            if (m > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox13.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = m.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price12.ToString();
                    }
                }
            }
            price += int.Parse(label14.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox24_Click(object sender, EventArgs e)     //유연함
        {
            q++;
            price16 += int.Parse(label24.Text);
            checkBox22.Checked = true;
            if (q == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox22.Text, label24.Text, q.ToString() }));
            }
            int count = listView1.Items.Count;
            if (q > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox22.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = q.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price16.ToString();
                    }
                }
            }
            price += int.Parse(label24.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox27_Click(object sender, EventArgs e)     //The One
        {
            r++;
            price17 += int.Parse(label23.Text);
            checkBox19.Checked = true;
            if (r == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox19.Text, label23.Text, r.ToString() }));
            }
            int count = listView1.Items.Count;
            if (r > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox19.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = r.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price17.ToString();
                    }
                }
            }
            price += int.Parse(label23.Text);
            textBox_price.Text = price.ToString();
        }

        //카테고리-소설
        private void pictureBox36_Click(object sender, EventArgs e)     //건널목
        {
            s++;
            price18 += int.Parse(label41.Text);
            checkBox36.Checked = true;
            if (s == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox36.Text, label41.Text, s.ToString() }));
            }
            int count = listView1.Items.Count;
            if (s > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox36.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = s.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price18.ToString();
                    }
                }
            }
            price += int.Parse(label41.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox35_Click(object sender, EventArgs e)     //제주도
        {
            t++;
            price19 += int.Parse(label40.Text);
            checkBox35.Checked = true;
            if (t == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox35.Text, label40.Text, t.ToString() }));
            }
            int count = listView1.Items.Count;
            if (t > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox35.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = t.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price19.ToString();
                    }
                }
            }
            price += int.Parse(label40.Text);
            textBox_price.Text = price.ToString();
        }

        private void pictureBox30_Click(object sender, EventArgs e)     //게임
        {
            u++;
            price20 += int.Parse(label38.Text);
            checkBox34.Checked = true;
            if (u == 1)
            {
                listView1.Items.Add(new ListViewItem(new string[] { checkBox34.Text, label38.Text, u.ToString() }));
            }
            int count = listView1.Items.Count;
            if (u > 1)
            {

                for (int forcount = 0; forcount < count; forcount++)
                {
                    if (listView1.Items[forcount].SubItems[0].Text == checkBox34.Text)
                    {
                        listView1.Focus();
                        listView1.Items[forcount].Selected = true;
                        listView1.Items[forcount].SubItems[2].Text = u.ToString();
                        listView1.Items[forcount].SubItems[1].Text = price20.ToString();
                    }
                }
            }
            price += int.Parse(label38.Text);
            textBox_price.Text = price.ToString();
        }

        private void button3_Click(object sender, EventArgs e)      //0행 -
        {
            int many = int.Parse(listView1.Items[0].SubItems[2].Text);
            int price = int.Parse(listView1.Items[0].SubItems[1].Text);
            int total_price = int.Parse(textBox_price.Text);

            if (many > 1)
            {
                total_price -= price / many;
                price -= price / many;
                many--;

                listView1.Items[0].SubItems[2].Text = many.ToString();
                listView1.Items[0].SubItems[1].Text = price.ToString();
            }
            textBox_price.Text = total_price.ToString();
        }

        private void button4_Click(object sender, EventArgs e)      //0행 +
        {
            int many1 = int.Parse(listView1.Items[0].SubItems[2].Text);
            int price1 = int.Parse(listView1.Items[0].SubItems[1].Text);
            int total_price1 = int.Parse(textBox_price.Text);

            total_price1 += price1 / many1;
            price1 += price1 / many1;
            many1++;

            listView1.Items[0].SubItems[2].Text = many1.ToString();
            listView1.Items[0].SubItems[1].Text = price1.ToString();

            textBox_price.Text = total_price1.ToString();
        }

        private void button2_Click(object sender, EventArgs e)  //검색
        {
            if (textBox2.Text == "" || textBox2.Text != checkBox6.Text)
            {
                MessageBox.Show("해당 도서가 존재하지 않습니다.");
            }
            else if (textBox2.Text == checkBox6.Text)
            {
                Form3 modal = new Form3(this);
                modal.ShowDialog();
            }

            else if (textBox2.Text == checkBox1.Text)
            {
                Form3 modal = new Form3(this);
                modal.ShowDialog();
            }
        }

        private void button5_Click(object sender, EventArgs e)      //1행 -
        {
            int many = int.Parse(listView1.Items[1].SubItems[2].Text);
            int price = int.Parse(listView1.Items[1].SubItems[1].Text);
            int total_price = int.Parse(textBox_price.Text);

            if (many > 1)
            {
                total_price -= price / many;
                price -= price / many;
                many--;

                listView1.Items[1].SubItems[2].Text = many.ToString();
                listView1.Items[1].SubItems[1].Text = price.ToString();
            }
            textBox_price.Text = total_price.ToString();
        }

        private void button6_Click(object sender, EventArgs e)      //1행 +
        {
            int many1 = int.Parse(listView1.Items[1].SubItems[2].Text);
            int price1 = int.Parse(listView1.Items[1].SubItems[1].Text);
            int total_price1 = int.Parse(textBox_price.Text);

            total_price1 += price1 / many1;
            price1 += price1 / many1;
            many1++;

            listView1.Items[1].SubItems[2].Text = many1.ToString();
            listView1.Items[1].SubItems[1].Text = price1.ToString();

            textBox_price.Text = total_price1.ToString();
        }

        private void button7_Click(object sender, EventArgs e)      //2행 -
        {
            int many = int.Parse(listView1.Items[2].SubItems[2].Text);
            int price = int.Parse(listView1.Items[2].SubItems[1].Text);
            int total_price = int.Parse(textBox_price.Text);

            if (many > 1)
            {
                total_price -= price / many;
                price -= price / many;
                many--;

                listView1.Items[2].SubItems[2].Text = many.ToString();
                listView1.Items[2].SubItems[1].Text = price.ToString();
            }
            textBox_price.Text = total_price.ToString();
        }

        private void button8_Click(object sender, EventArgs e)      //2행 +
        {
            int many1 = int.Parse(listView1.Items[2].SubItems[2].Text);
            int price1 = int.Parse(listView1.Items[2].SubItems[1].Text);
            int total_price1 = int.Parse(textBox_price.Text);

            total_price1 += price1 / many1;
            price1 += price1 / many1;
            many1++;

            listView1.Items[2].SubItems[2].Text = many1.ToString();
            listView1.Items[2].SubItems[1].Text = price1.ToString();

            textBox_price.Text = total_price1.ToString();
        }
    }
}
